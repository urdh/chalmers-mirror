% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file generates the initial guess for the temperatures in the nodes,
% with correct temperatures at the boundaries.

function [T_0] = initial(Xnode, Ynode, T1, T2)
    
    % Guess zero temperature
    T_0 = zeros(size(Xnode));
    
    % Fix the prescribed boundary temperatures
    T_0(1,:) = T1; 
    T_0(:,end) = T2;
    T_0(:,1) = 10.*(1 + 2.*Ynode(:,1)./(Ynode(end)));
    
end
