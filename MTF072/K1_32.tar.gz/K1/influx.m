% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the influx for one iteration given the temperature
% matrix T.
function influx = influx(Xnode, Ynode, T)
    
    % Get the flux for the entire domain
    [qx qy] = flux(Xnode, Ynode, T);
    qx = abs(qx);
    qy = abs(qy);
    
    % Extract flux sum at the boundary nodes
    E = sum(qx(:,end));
    W = sum(qx(:,1  ));
    N = sum(qy(:,end));
    S = sum(qy(:,1  ));
    
    % Calculate the total influx
    influx = E + W + N + S;
end
    