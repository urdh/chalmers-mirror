% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the coefficients and sources for a point P given
% coordinates for the nodes (Xnode, Ynode) and faces (Xface, Yface),
% temperature matrix T, and point position in matrix (i, j).
% The output is given as a = [east west north south point Su Sp]


function a = coefficients(Xface, Yface, Xnode, Ynode, T, i, j)
    
    % Get the heat conductivity for all nodes
    k = conductivity(T);
    
    % Get the linearized source terms Su and Sp
    S = source(T(i,j));
    
    % Compute the cell size
    deltaX = Xface(i, j) - Xface(i, j-1);
    deltaY = Yface(i, j) - Yface(i-1, j);
    
    % Compute distances to neighbor nodes
    dX_e = Xnode(i, j+1) - Xnode(i, j);
    dX_w = Xnode(i, j) - Xnode(i, j-1);
    dY_n = Ynode(i+1, j) - Ynode(i, j);
    dY_s = Ynode(i, j) - Ynode(i-1, j);
    
    % Interpolate to find the heat conductivity at the faces. Start by
    % finding the interpolation factors
    fe = 0.5*deltaX/dX_e;
    fw = 0.5*deltaX/dX_w;
    fn = 0.5*deltaY/dY_n;
    fs = 0.5*deltaY/dY_s;
    % and then compute the face values
    ke = fe*k(i, j+1) + (1 - fe)*k(i,j);
    kw = fw*k(i, j) + (1 - fw)*k(i,j-1);
    kn = fn*k(i+1, j) + (1 - fn)*k(i,j);
    ks = fs*k(i, j) + (1 - fs)*k(i-1,j);
    
    % We can now compute the coefficients
    ae = ke*deltaY/dX_e;
    aw = kw*deltaY/dX_w;
    an = kn*deltaX/dY_n;
    as = ks*deltaX/dY_s;
    
    % Set the boundary condition dT/dy = 0 implicitly at "boundary 3" by
    % setting an = 0
    if i+1 == size(Ynode, 1)
        
        an = 0;
        
    end
    
    ap = ae + aw + an + as - S(2);
    
    % Put all values in a vector according to the desired output
    a = [ae aw an as ap S(1) S(2)];
    
end
