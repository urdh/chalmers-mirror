% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the linearized source terms Su and Sp given the node
% temperature Tp. The output is on the form S = [Su Sp].

function S = source(Tp)
    
    % Define the constants c1 and c2 from the given task
    c1 = 25;
    c2 = 0.1;
    
    % Compute the two terms
    Su = 15*c1;
    Sp = -15*c2*Tp;
    
    S = [Su Sp];
    
end
