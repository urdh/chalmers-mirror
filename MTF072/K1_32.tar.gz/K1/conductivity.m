% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the heat conductivity in the domain given the
% temperature matrix T.

function k = conductivity(T)
    
    % Get the temperature T1 at "boundary 1" (y = 0)
    T1 = T(1,1);
    
    % Compute k according to the given formula
    k = 2*(1 + 20*T/T1);
end
