% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file is the man file that calls other functions to do its work.

function solver()
    
    clear all
    close all
    clc
    
    % Give the dimensions of the domain
    H = 1;
    L = 1;
    
    % And the number of nodes in each direction
    nx = 20;
    ny = 20;
    
    % Give the temperatures on boundary 1 and 2 (boundary 3 and 4 are
    % specified in coefficients.m and initial.m, respactively)
    T1 = 10;
    T2 = 20;
    
    % Specify the maximum residual
    epsilon = 1e-4;
    
    % Generate the mesh
    [Xface, Yface] = meshing(L, H, nx, ny, 1.150, 1.075);
    
    % Retrive the node coordinates
    [Xnode, Ynode] = nodes(Xface, Yface);
    
    % Make an initial guess of the temperatures, with correct temperatures
    % at the boundaries
    T_0 = initial(Xnode, Ynode, T1, T2);
    
    % Solve for the temperatures
    T = gauss_seidel(Xface, Yface, Xnode, Ynode, T_0, epsilon);
    
    % Plot the soultion
    %figure(1)
    %surf(Xnode, Ynode, T)
    %figuresize(7, 5, 'centimeters')
    %saveas(gcf, 'none', 'pdf')
    figure(2)
    contour(Xnode, Ynode, T, floor((nx+ny)/2))
    colorbar('North')
    axis([0 1 0 1])
    %axis square
    figuresize(7, 5, 'centimeters')
    saveas(gcf, 'contour', 'pdf')
    
    % Plot the flux
    figure(3)
    [qx qy] = flux(Xnode, Ynode, T);
    quiver(Xnode, Ynode, qx, qy, 5);
    axis([0 1 0 1])
    %axis square
    figuresize(7, 5, 'centimeters')
    saveas(gcf, 'quiver-scaled-5x', 'pdf')
    
end
