% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the normalized residuals for one iteration given the
% temperature matrix T.


function residual = residual(Xface, Yface, Xnode, Ynode, T)
    
    % Initialize
    residual = 0;
    
    for i = 2:(size(Ynode, 1) - 1)
            
            for j = 2:(size(Ynode, 2) - 1)
                
                % Get the coefficients with sources 
                % a = [east west north south point Su Sp]
                a = coefficients(Xface, Yface, Xnode, Ynode, T, i, j);
                
                % Compute and add the node residual to the sum of residuals
                noderes = abs((a(1)*T(i,j+1) + a(2)*T(i,j-1) + a(3)*T(i+1,j) ...
                    + a(4)*T(i-1,j) + a(6)) - T(i,j)*a(5));
                
                residual = residual + noderes;
                
            end
            
    end
    
    % Get the total flux into the domain
    flux = influx(Xnode, Ynode, T);
    
    % Normalize the residuals with the total flux into the domain
    residual = residual/flux;
    
end
