% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the heat flux in the entire domain, including
% boundaries, given the temperature matrix T.


function [qx qy] = flux(Xnode, Ynode, T)
    
    qx = zeros(size(T));
    qy = zeros(size(T));
    
    % Get the heat conductivity
    k = conductivity(T);
    
    % Start by finding the fluxes inside the domain usin central
    % differencing
    for i = 2:(size(T, 1) - 1)
            
            for j = 2:(size(T, 2) - 1)
                
                deltaX = Xnode(i,j+1) - Xnode(i,j-1);
                deltaY = Ynode(i+1,j) - Ynode(i-1,j);
                
                qx(i,j) = k(i,j)*(T(i,j+1) - T(i,j-1))/deltaX;
                qy(i,j) = k(i,j)*(T(i+1,j) - T(i-1,j))/deltaY;
                
            end
            
    end
    
    % Find the fluxes at boundary 1
    for j = 2:(size(T, 2) - 1)
        
        deltaX = Xnode(1,j+1) - Xnode(1,j-1);
        deltaY = Ynode(2,j) - Ynode(1,j);
        
        qx(1,j) = k(1,j)*(T(1,j+1) - T(1,j-1))/deltaX;
        qy(1,j) = k(1,j)*(T(2,j) - T(1,j))/deltaY;
        
    end
    
    % Boundary 2
    for i = 2:(size(T, 1) - 1)
        
        deltaX = Xnode(i,end) - Xnode(i,end-1);
        deltaY = Ynode(i+1,end) - Ynode(i-1,end);
        
        qx(i,end) = k(i,end)*(T(i,end) - T(i,end-1))/deltaX;
        qy(i,end) = k(i,end)*(T(i+1,end) - T(i-1,end))/deltaY;
        
    end
    
    % Boundary 3
    for j = 2:size(T, 2) - 1
        
        deltaX = (Xnode(end,j) - Xnode(end-1,j));
        deltaY = (Ynode(end,j+1) - Ynode(end,j-1));
        
        qx(end,j) = k(end,j)*(T(end,j) - T(end-1,j))/deltaX;
        qy(end,j) = k(end,j)*(T(end,j+1) - T(end,j-1))/deltaY;
        
    end
    
    % Boundary 4
    for i = 2:(size(T, 1) - 1)
        
        deltaX = Xnode(i,2) - Xnode(i,1);
        deltaY = Ynode(i+1,1) - Ynode(i-1,1);
        
        qx(i,1) = k(i,1)*(T(i,2) - T(i,1))/deltaX;
        qy(i,1) = k(i,1)*(T(i+1,1) - T(i-1,1))/deltaY;
        
    end
    
    qx = -qx;
    qy = -qy;
    
end