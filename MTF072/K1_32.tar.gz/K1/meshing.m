% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file generates the mesh for the domain with dimensions LxH with nx
% elements in x-direction and ny elements in y-direction with growth ratios
% lx and ly. lx = ly = 1 gives an equidistant mesh.

function [X, Y] = meshing(L, H, nx, ny, lx, ly)
    
    % Initialize variables
    x = linspace(0, L, nx);
    y = linspace(0, H, ny);

    % Make clever mesh in x-direction
    if lx ~= 1

        lambda_x = lx;

	% Compute the inxrease at x = 0 and x = L
        dx = (L/2)*(lambda_x-1)/(lambda_x^floor(nx/2+1)-1);

        for j=2:floor(nx/2)

           x(j) = x(j-1) + dx * lambda_x^(j-1);
	   
 	   % Mirror around center
           x(end-j+1) = (L-x(j));

        end
    end

    % Make clever mesh in y-direction
    if ly ~= 1
	
        lambda_y = ly;
	
	% Compute the increase at y = 0        
	dy = H*(lambda_y-1)/(lambda_y^ny-1);

        for i=2:ny

            y(i) = y(i-1) + dy * lambda_y^(i-1);

        end

    end
    
    % Create the mesh
    [X, Y] = meshgrid(x, y);
end
