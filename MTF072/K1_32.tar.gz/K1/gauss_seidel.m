% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file is the actual iterative solver, using the Gauss-Seidel 
% iterative method. The function returns a matrix of solutions in every 
% node given the node (Xnode, Ynode) and face coordinates (Xface, Yface)
% as well as the initial guess T_0 and maximum normalized residual epsilon.


function [T] = gauss_seidel(Xface, Yface, Xnode, Ynode, T_0, epsilon)
    
    
    % Initialize the temperature matrix
    T = T_0;
    
    % Create some kind of homemade do while-loop to ensure that at least
    % one iteration is done
    not_done = true;
    
    % Count the number of iterations
    numberOfIterations = 0;
    
    while not_done
        
        for i = 2:(size(Ynode, 1) - 1)
            
            for j = 2:(size(Ynode, 2) - 1)
                
                % Get the coefficients with sources 
                % a = [east west north south point Su Sp]
                a = coefficients(Xface, Yface, Xnode, Ynode, T, i, j);
                
                % Compute the node temperature
                T(i,j) = (a(1)*T(i,j+1) + a(2)*T(i,j-1) + a(3)*T(i+1,j) ...
                    + a(4)*T(i-1,j) + a(6))/a(5);
            end
            
        end
        
        % Get the normalized residuals
        residuals = residual(Xface, Yface, Xnode, Ynode, T)
        
        % Determine if the convergence criteria is met
        not_done = residuals > epsilon;
        
        numberOfIterations = numberOfIterations + 1;
        
        % Instead of convergence criteria, remove later!
        %if numberOfIterations == 1000
           
        %    not_done = false;
            
        %end
        
    end
    
    % Set correct temperature on "boundary 3" due to implicit boundary
    % condition
    T(end, :) = T(end-1, :);
    
    numberOfIterations
    
    
end
