% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file plots the results

function plotter()

    clear all
    close all
    
    load k-omega.mat
    load ../Data/u2_dns.dat
    load ../Data/v2_dns.dat
    load ../Data/w2_dns.dat
    load ../Data/u_dns.dat
    load ../Data/dns_data.dat
    
    % Variables
    nu = 1/395;
    ustar = 1;
    sigma_k = 1;
    eps = 0.09*omega.*k ;
    
    % DNS data
    k_dns=0.5*(u2_dns + v2_dns +  w2_dns);
    eps_dns=dns_data(:,2)*ustar/nu;
    uv_dns = dns_data(:,3)*ustar/nu;
    pres_dns = dns_data(:,4)*ustar/nu;
    trip_dns = dns_data(:,5)*ustar/nu;
    visc_dns = dns_data(:,6)*ustar/nu;
    
    % Generate the mesh
    Yface = meshing('../Data/y_dns.dat');
    
    % Retrive the node coordinates
    Ynode = nodes(Yface);
    
    % Compute Reynolds stresses
    uv = zeros(size(Ynode));
    
    for i = 2:(length(Ynode) - 1)
        
        uv(i) = production(Yface, Ynode, U, k, omega, nu, i);
        
    end
    
    % Compute diffusion due to triple velocity fluctuations
    trip = zeros(size(Ynode));
    for i = 2:(length(Ynode) - 1)
        
        nu_t = viscosity(k, omega, nu, i);
        
        trip(i) = nu_t(2)/sigma_k*derivative(Yface, Ynode, k, i);
        
    end
    
    trip_diff = zeros(size(Ynode));
    for i = 2:(length(Ynode) - 1)
        
        trip_diff(i) = derivative(Yface, Ynode, trip, i);
        
    end
    
    % Compute the viscous diffusion
    visc = zeros(size(Ynode));
    for i = 2:(length(Ynode) - 1)

        visc(i) = nu*derivative(Yface, Ynode, k, i);
        
    end
    
    visc_diff = zeros(size(Ynode));
    for i = 2:(length(Ynode) - 1)
        
        visc_diff(i) = derivative(Yface, Ynode, visc, i);
        
    end
    
    % Compute the turbulent length scales
    l_calc = k.^(3/2)./eps;
    l_dns = k_dns.^(3/2)./eps_dns;
    
    % Compute Kolmogorov scales
    l_kol_calc = (nu^3./eps).^(1/4);
    l_kol_dns = (nu^3./eps_dns).^(1/4);
    
    t_kol_calc = (nu./eps).^(1/2);
    t_kol_dns = (nu./eps_dns).^(1/2);
    
    u_kol_calc = (nu.*eps).^(1/4);
    u_kol_dns = (nu.*eps_dns).^(1/4);
    
    
    % Plot the soultion
    yplus = Ynode/nu;
    
    figure(1)
    semilogx(yplus, U, 'k')
    hold on
    grid on
    semilogx(Yface/nu, u_dns, 'ok')
    axis([1 400 0 25])
    xlabel('y^+')
    ylabel('u [m/s]')
    title('Mean velucity U')
    legend('Calculated data','DNS data','Location','NorthWest')
%     matlab2tikz('Figures/u.tikz','height', '5cm', 'width', '5cm');
    
    figure(2)
    plot(yplus, k, 'k')
    hold on
    grid on
    plot(Yface/nu, k_dns, 'ok')
    xlabel('y^+')
    ylabel('k [m^2/s^2]')
    title('Turbulent kinetic energy k')
    legend('Calculated data','DNS data','Location','NorthEast')
%     matlab2tikz('Figures/k.tikz','height', '5cm', 'width', '5cm');
    
    figure(3)
    plot(yplus, eps, 'k')
    hold on
    grid on
    plot(Yface/nu, eps_dns, 'ok')
    xlabel('y^+')
    ylabel('\varepsilon [m^2/s^3]')
    title('Dissipation \varepsilon')
    legend('Calculated data','DNS data','Location','NorthEast')
%     matlab2tikz('Figures/eps.tikz','height', '5cm', 'width', '5cm');
    
    figure(4)
    plot(yplus(1:end-1), uv(1:end-1), 'k')
    hold on
    grid on
    plot(Yface/nu, uv_dns, 'ok')
    xlabel('y^+')
    ylabel('\bar{uv}\frac{\partial \bar{U}}{\partial y} [m^2/s^3]')
    title('Production term')
    legend('Calculated data','DNS data','Location','NorthEast')
%     matlab2tikz('Figures/production.tikz','height', '5cm', 'width', '5cm');
    
	figure(5)
    plot(yplus(1:end-1), trip_diff(1:end-1), 'k')
    hold on
    grid on
    plot(Yface/nu, trip_dns+pres_dns, 'ok')
    axis([0 150 -30 30])
    xlabel('y^+')
    ylabel('\frac{\partial}{\partial y}(\bar{vk}) [m^2/s^3]')
    title('Turbulent diffusion')
    legend('Calculated data','DNS data','Location','NorthEast')
%     matlab2tikz('Figures/turbdiff.tikz','height', '5cm', 'width', '5cm');
    
    figure(6)
    plot(yplus(1:end-1), visc_diff(1:end-1), 'k')
    hold on
    grid on
    plot(Yface/nu, visc_dns, 'ok')
    axis([0 50 -40 100])
    xlabel('y^+')
    ylabel('\nu\frac{\partial^2 k}{\partial y^2} [m^2/s^3]')
    title('Viscous diffusion')
    legend('Calculated data','DNS data','Location','NorthEast')
%     matlab2tikz('Figures/viscdiff.tikz','height', '5cm', 'width', '5cm');

    figure(7)
    plot(yplus, l_calc, 'k')
    hold on
    grid on
    plot(Yface/nu, l_dns, 'ok')
    xlabel('y^+')
    ylabel('Turbulent length scale \frac{k^\frac{3}{2}}{\varepsilon} [m]')
    legend('Calculated data','DNS data','Location','NorthWest')
%     matlab2tikz('Figures/turblength.tikz','height', '5cm', 'width', '5cm');
    
    figure(8)
    subplot(1,3,1)
    plot(yplus(2:end), l_kol_calc(2:end), 'k')
    hold on
    grid on
    plot(Yface/nu, l_kol_dns, 'ok')
    xlabel('y^+')
    ylabel('Kolmogorov length scale [m]')
    legend('Calculated data','DNS data','Location','NorthWest')
    
    subplot(1,3,2)
    plot(yplus(2:end), t_kol_calc(2:end), 'k')
    hold on
    grid on
    plot(Yface/nu, t_kol_dns, 'ok')
    xlabel('y^+')
    ylabel('Kolmogorov time scale [s]')
    legend('Calculated data','DNS data','Location','NorthWest')
    
    subplot(1,3,3)
    plot(yplus, u_kol_calc, 'k')
    hold on
    grid on
    plot(Yface/nu, u_kol_dns, 'ok')
    xlabel('y^+')
    ylabel('Kolmogorov velocity scale [m/s]')
    legend('Calculated data','DNS data','Location','NorthEast')
%     matlab2tikz('Figures/kolmogorov.tikz','height', '5cm', 'width', '15cm');

end