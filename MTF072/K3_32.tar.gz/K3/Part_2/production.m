% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

function production = production(Yface, Ynode, U, k, omega, nu, i)
    
    % Compute viscosity
    nu_t = viscosity(k, omega, nu, i);
    
    % Get the velocity gradient
    dU_dy = derivative(Yface, Ynode, U, i);
    
    % Compute the production
    production = nu_t(2)*(dU_dy)^2;

end