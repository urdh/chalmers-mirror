% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the turbulent viscosity.

function nu_t = viscosity(k, omega, nu, i)
    
    c_mu = 1;
    
    % Pick the interesting values
    k = k(i-1:i+1);
    omega = omega(i-1:i+1);
    
    % Compute local Reynolds number
    R_t = abs(k./(nu*omega));
    
    % Compute damping function
    f_mu = 0.09 + (0.91 + 1./(R_t.^3)).*(1 - exp(-(R_t/25).^2.75));
    
    nu_t = c_mu*f_mu.*k./omega;
    
    if i == 2
        nu_t(1) = 0;
    end
    
end