% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file is the man file that calls other functions to do its work.

function solver()
    
    clear all
    close all
    clc
    
    % Variables
    nu = 1/395;
    ustar = 1;
    
    % Specify the maximum residual
    epsilon = 1e-3;
    
    % Specify the underrelaxation factors as 
    % alpha = [alpha_U alpha_k alpha_eps]
    alpha = [1 1 0.9];
    
    % Generate the mesh
    Yface = meshing('../Data/y_dns.dat');
    
    % Retrive the node coordinates
    Ynode = nodes(Yface);
    
    % Make an initial guess of the temperatures, with correct temperatures
    % at the boundaries
    [U_0 k_0 omega_0] = initial(Ynode);
    
    % Solve for the temperatures
    [U k omega] = gauss_seidel(Yface, Ynode, U_0, k_0, omega_0, epsilon, alpha);

    %save('k-omega.mat', 'U', 'k', 'omega', 'yplus')

    plotter()
    
end
