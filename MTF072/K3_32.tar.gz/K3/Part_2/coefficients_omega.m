% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the eps coefficients and sources for a point P given
% coordinates for the nodes (Ynode) and faces (Yface),
% velocity U, k and eps, and point position in matrix (i).
% The output is given as a = [north south point Su Sp]


function a = coefficients_omega(Yface, Ynode, U, k, omega, alpha_omega, i)
    
    % Constants
    nu = 1/395;
    sigma_omega = 1.8;
    c1omega = 0.49;
    c2omega = 0.072;
    c_omega = 1.1;
    
    % Get the turbulent viscosity
    nu_t = viscosity(k, omega, nu, i);
    
    % Get the heat conductivity for all nodes
    Gamma = (nu + nu_t./sigma_omega);
    
    % Compute the cell size
    deltaY = Yface(i) - Yface(i-1);
    
    % Compute distances to neighbor nodes
    dY_n = Ynode(i+1) - Ynode(i);
    dY_s = Ynode(i) - Ynode(i-1);
    
    % Interpolate to find the heat conductivity at the faces. Start by
    % finding the interpolation factors
    fn = 0.5*deltaY/dY_n;
    fs = 0.5*deltaY/dY_s;
    
    % and then compute the face values
    kn = fn*Gamma(3) + (1 - fn)*Gamma(2);
    ks = fs*Gamma(2) + (1 - fs)*Gamma(1);
    
    % We can now compute the coefficients
    an = kn/dY_n;
    as = ks/dY_s;
    
    % Boundary conditions
    if i == length(Ynode)-1
       an = 0;
    end
    
    % Calculate the source terms for the omega equation
    Sp = -omega(i)*deltaY*c2omega;
    Su = omega(i)/k(i)*deltaY*c1omega*production(Yface, Ynode, U, k, omega, nu, i);
    
    % Compute the gradients of k and omega
    dk_dy = derivative(Yface, Ynode, k, i);
    domega_dy = derivative(Yface, Ynode, omega, i);
    
    % Compute the cross-diffusion term
    crossdiff = c_omega/k(i)*(nu + nu_t(2))*dk_dy*domega_dy;
    
    % Put crossdiff in Sp if negative or in Su if positive
    if crossdiff < 0
        
        Sp = Sp + crossdiff/omega(i)*deltaY;
        
    else
        
        Su = Su + crossdiff*deltaY;
        
    end
    
    ap = an + as - Sp;
    
    % Introduce under-relaxation
    ap = ap/alpha_omega;
    Su = Su + ap*(1 - alpha_omega)*omega(i);
    
    % Put all values in a vector according to the desired output
    
    a = [an as ap Su Sp];
    
end
