% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the normalized residuals for one iteration given the
% velocity vector U, as well as k and eps.


function residual = residual(Yface, Ynode, U, k, omega, alpha)
    
    % Initialize
    rU = 0;
    rk = 0;
    romega = 0;
    alpha = [1 1 1];
    
    for i = 2:(length(Ynode) - 1)
                
        % Get coefficients for U
        a = coefficients_U(Yface, Ynode, U, k, omega, alpha(1), i);
        % Compute and add the node residual to the sum of residuals
        rU = rU + abs((a(1)*U(i+1) + a(2)*U(i-1) + a(4)) - U(i)*a(3));
        % Get coefficients for k
        a = coefficients_k(Yface, Ynode, U, k, omega, alpha(2), i);
        % Compute and add the node residual to the sum of residuals
        rk = rk + abs((a(1)*k(i+1) + a(2)*k(i-1) + a(4)) - k(i)*a(3));
        % Get coefficients for eps
       
        % Compute and add the node residual to the sum of residuals
        if i ~= 2
            a = coefficients_omega(Yface, Ynode, U, k, omega, alpha(3), i);
            romega = romega + abs((a(1)*omega(i+1) + a(2)*omega(i-1) + a(4)) - omega(i)*a(3));
        end
    end
    
    % Calculate the normalization
    %TODO: korrekt?
    F = sum(U(2:end-1).^2 .* diff(Yface));
    
    % Normalize the residuals with the total flux into the domain
    residual = [rU rk romega]/F;
    
end
