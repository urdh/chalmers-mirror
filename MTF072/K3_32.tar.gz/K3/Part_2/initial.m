% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% 

function [U_0 k_0 omega_0] = initial(Ynode)
    
    nu = 1/395;
    c_k = 0.09;
    
    % Guess zero
    U_0 = ones(size(Ynode));
    k_0 = ones(size(Ynode));
    omega_0 = ones(size(Ynode));
    
    % Fix the prescribed boundary conditions
    k_0(1) = 1e-12;
    U_0(1) = 0;
    
    omega_0(2) = 2*nu/(c_k*Ynode(2)^2);
    
end
