% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the spatial derivative of the variable phi.

function dphi_dy = derivative(Yface, Ynode, phi, i)

    % Compute the cell size
    deltaY = Yface(i) - Yface(i-1);
    
    % Compute distances to neighbor nodes
    dY_n = Ynode(i+1) - Ynode(i);
    dY_s = Ynode(i) - Ynode(i-1);
    
    % Interpolate to find the heat conductivity at the faces. Start by
    % finding the interpolation factors
    fn = 0.5*deltaY/dY_n;
    fs = 0.5*deltaY/dY_s;
    % and then compute the face values
    phi_n = fn*phi(i+1) + (1 - fn)*phi(i);
    phi_s = fs*phi(i) + (1 - fs)*phi(i-1);
    
    % Set zero gradient at center of channel
    if i == (length(Ynode) - 1)
        
        phi_n = phi_s;
        
    end
    
    dphi_dy = (phi_n - phi_s)/deltaY;
    
end