% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file is the man file that calls other functions to do its work.

function solver()
    
    clear all
    close all
    clc
    
    load ../Data/u2_dns.dat
    load ../Data/v2_dns.dat
    load ../Data/w2_dns.dat
    load ../Data/u_dns.dat
    load ../Data/dns_data.dat
    
    % Variables
    nu = 1/395;
    ustar = 1;

    % DNS data
    k_dns=0.5*(u2_dns + v2_dns +  w2_dns);
    eps_dns=dns_data(:,2)*ustar/nu;
    
    % Specify the maximum residual
    epsilon = 1e-4;
    
    % Specify the underrelaxation factors as 
    % alpha = [alpha_U alpha_k alpha_eps]
    alpha = [1 1 1];
    
    % Generate the mesh
    Yface = meshing('../Data/y_dns.dat');
    
    % Retrive the node coordinates
    Ynode = nodes(Yface);
    
    % Make an initial guess of the temperatures, with correct temperatures
    % at the boundaries
    [U_0 k_0 eps_0] = initial(Ynode);
    
    % Solve for the temperatures
    [U k eps] = gauss_seidel(Yface, Ynode, U_0, k_0, eps_0, epsilon, alpha);
    
    % Plot the soultion
    yplus = Ynode/nu;
    
    figure(1)
    semilogx(yplus, U, 'k')
    hold on
    grid on
    semilogx(Yface/nu, u_dns, 'ok')
    ylabel('y^+')
    xlabel('u [m/s]')
    legend('Calculated data','DNS data','Location','NorthWest')
    matlab2tikz('Figures/u.tikz','height', '5cm', 'width', '5cm');
    
    figure(2)
    plot(yplus, k, 'k')
    hold on
    grid on
    plot(Yface/nu, k_dns, 'ok')
    ylabel('y^+')
    xlabel('k [m^2/s^2]')
    legend('Calculated data','DNS data','Location','NorthEast')
    matlab2tikz('Figures/k.tikz','height', '5cm', 'width', '5cm');
    
    figure(3)
    plot(yplus, eps, 'k')
    hold on
    grid on
    plot(Yface/nu, eps_dns, 'ok')
    ylabel('y^+')
    xlabel('\varepsilon [m^2/s^3]')
    legend('Calculated data','DNS data','Location','NorthEast')
    matlab2tikz('Figures/eps.tikz','height', '5cm', 'width', '5cm');
    
end
