% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

function production = production(Yface, Ynode, U, k, eps, i)
    
    % Constants and nu_t
    c_nu = 0.09;
    nu_t = c_nu*k(i)^2/eps(i);
    
    % Compute the cell size
    deltaY = Yface(i) - Yface(i-1);
    
    % Compute distances to neighbor nodes
    dY_n = Ynode(i+1) - Ynode(i);
    dY_s = Ynode(i) - Ynode(i-1);
    
    % Interpolate to find the heat conductivity at the faces. Start by
    % finding the interpolation factors
    fn = 0.5*deltaY/dY_n;
    fs = 0.5*deltaY/dY_s;
    % and then compute the face values
    Un = fn*U(i+1) + (1 - fn)*U(i);
    Us = fs*U(i) + (1 - fs)*U(i-1);
    
    % Set zero velocity gradient at center of channel
    if i == (length(Ynode) - 1)
        Un = Us;
    end
    
    production = nu_t*((Un - Us)/deltaY)^2;

end