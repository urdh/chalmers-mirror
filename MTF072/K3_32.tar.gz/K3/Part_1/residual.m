% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the normalized residuals for one iteration given the
% velocity vector U, as well as k and eps.


function residual = residual(Yface, Ynode, U, k, eps, alpha)
    
    % Initialize
    rU = 0;
    rk = 0;
    reps = 0;
    
    for i = 2:(length(Ynode) - 1)
                
        % Get coefficients for U
        a = coefficients_U(Yface, Ynode, U, k, eps, alpha(1), i);
        % Compute and add the node residual to the sum of residuals
        rU = rU + abs((a(1)*U(i+1) + a(2)*U(i-1) + a(4)) - U(i)*a(3));
        % Get coefficients for k
        a = coefficients_k(Yface, Ynode, U, k, eps, alpha(2), i);
        % Compute and add the node residual to the sum of residuals
        rk = rk + abs((a(1)*k(i+1) + a(2)*k(i-1) + a(4)) - k(i)*a(3));
        % Get coefficients for eps
        a = coefficients_eps(Yface, Ynode, U, k, eps, alpha(3), i);
        % Compute and add the node residual to the sum of residuals
        reps = reps + abs((a(1)*eps(i+1) + a(2)*eps(i-1) + a(4)) - eps(i)*a(3));

    end
    
    % Calculate the normalization
    %TODO: korrekt?
    F = sum(U(2:end-1).^2 .* diff(Yface));
    
    % Normalize the residuals with the total flux into the domain
    residual = [rU rk reps]/F;
    
end
