% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file loads the mesh.
% All data needed is the path to the file containing the mesh.

function [Y] = meshing(filename_y)
    
    % Read the given mesh
    Y = load(filename_y);
    
end
