% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file is the actual iterative solver, using the Gauss-Seidel 
% iterative method. The function returns a matrix of solutions in every 
% node given the node (Xnode, Ynode) and face coordinates (Xface, Yface)
% as well as the initial guess T_0 and maximum normalized residual epsilon.


function [U,k,eps] = gauss_seidel(Yface, Ynode, U_0, k_0, eps_0, epsilon, alpha)
    
    % Initialize the temperature matrix
    U = U_0;
    k = k_0;
    eps = eps_0;
    
    % Create some kind of homemade do while-loop to ensure that at least
    % one iteration is done
    not_done = true;
    
    % Count the number of iterations
    numberOfIterations = 0;
    
    while not_done
        
        for i = 2:(length(Ynode) - 1)
                
            % a = [north south point Su Sp]
            au = coefficients_U(Yface, Ynode, U, k, eps, alpha(1), i);
            ak = coefficients_k(Yface, Ynode, U, k, eps, alpha(2), i);
            aeps = coefficients_eps(Yface, Ynode, U, k, eps, alpha(3), i);
            
            % Calculate new U
            U(i) = (au(1)*U(i+1) + au(2)*U(i-1) + au(4))/au(3);
            % Calculate new k
            k(i) = (ak(1)*k(i+1) + ak(2)*k(i-1) + ak(4))/ak(3);
            % Calculate new eps
            eps(i) = (aeps(1)*eps(i+1) + aeps(2)*eps(i-1) + aeps(4))/aeps(3);
            
        end
        
        % Get the normalized residuals
        residuals = residual(Yface, Ynode, U, k, eps, alpha);
        
        % Determine if the convergence criteria is met
        not_done = max(residuals) > epsilon;
        
        numberOfIterations = numberOfIterations + 1;
        
        % Diagnostic, mostly
        if mod(numberOfIterations, 100) == 0
            disp(['Iteration ', num2str(numberOfIterations), ...
                  ' with residuals ', num2str(residuals)])
        end
        
    end
    
    % Fix the boundaries
    eps(1) = eps(2);
    eps(end) = eps(end-1);
    
    U(end) = U(end-1);
    k(end) = k(end-1);
    
    disp(['Done after ', num2str(numberOfIterations), ' iterations.'])
    
end
