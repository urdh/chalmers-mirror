% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the eps coefficients and sources for a point P given
% coordinates for the nodes (Ynode) and faces (Yface),
% velocity U, k and eps, and point position in matrix (i).
% The output is given as a = [north south point Su Sp]


function a = coefficients_eps(Yface, Ynode, U, k, eps, alpha_eps, i)
    
    % Constants
    c_mu = 0.09;
    nu = 1/395;
    sigma_eps = 1.33;
    c1eps = 1.44;
    c2eps = 1.92;

    % Get the heat conductivity for all nodes
    Gamma = (nu + c_mu*k.^2./eps/sigma_eps);
    
    % Compute the cell size
    deltaY = Yface(i) - Yface(i-1);
    
    % Calculate the source terms for the eps equation
    Sp = -eps(i)/k(i)*deltaY*c2eps;
    Su = eps(i)/k(i)*deltaY*c1eps*production(Yface, Ynode, U, k, eps, i);
    
    % Compute distances to neighbor nodes
    dY_n = Ynode(i+1) - Ynode(i);
    dY_s = Ynode(i) - Ynode(i-1);
    
    % Interpolate to find the heat conductivity at the faces. Start by
    % finding the interpolation factors
    fn = 0.5*deltaY/dY_n;
    fs = 0.5*deltaY/dY_s;
    
    % and then compute the face values
    kn = fn*Gamma(i+1) + (1 - fn)*Gamma(i);
    ks = fs*Gamma(i) + (1 - fs)*Gamma(i-1);
    
    % We can now compute the coefficients
    an = kn/dY_n;
    as = ks/dY_s;
    
    % Boundary conditions
    if i == length(Ynode)-1
       an = 0;
    end
    
    if i == 2
       as = 0;
    end
    
    ap = an + as - Sp;
    
    % Introduce under-relaxation
    ap = ap/alpha_eps;
    Su = Su + ap*(1 - alpha_eps)*eps(i);
    
    % Put all values in a vector according to the desired output
    
    a = [an as ap Su Sp];
    
end
