% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file generates the node coordinates given the matrices for the
% coordinates of the faces Xface and Yface from meshing.m

function [Ynode] = nodes(Yface)
    
    % Initialize the two matrices and account for the nodes at the
    % boundaries
    Ynode = zeros(length(Yface)+1,1);
    
    % Compute the node coordinates for the inner nodes
    for i = 2:length(Yface)
            
        Ynode(i) = (Yface(i) + Yface(i-1))/2;
        
    end
    
    % Fix the boundary nodes in a rather ugly way by just copying the
    % correct values from other rows/columns and the face matrices

    Ynode(1) = Yface(1);
    Ynode(end) = Yface(end);
    
end
