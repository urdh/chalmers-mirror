% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% 

function [U_0 k_0 eps_0] = initial(Ynode)
    
    % Guess zero
    U_0 = ones(size(Ynode));
    k_0 = ones(size(Ynode));
    eps_0 = ones(size(Ynode));
    
    % Fix the prescribed boundary conditions
    k_0(1) = 0;
    U_0(1) = 0;
    
end
