% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k3
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the U coefficients and sources for a point P given
% coordinates for the nodes (Ynode) and faces (Yface),
% velocity U, k and eps, and point position in matrix (i).
% The output is given as a = [north south point Su Sp]


function a = coefficients_U(Yface, Ynode, U, k, eps, alpha_U, i)
    
    % Constants
    c_nu = 0.09;
    nu = 1/395;

    % Get the heat conductivity for all nodes
    Gamma = (nu + c_nu*k.^2./eps);
    
    % Compute the cell size
    deltaY = Yface(i) - Yface(i-1);
    
    % Calculate the source terms for the U equation
    Sp = 0;
    Su = deltaY*1;
    
    % Compute distances to neighbor nodes
    dY_n = Ynode(i+1) - Ynode(i);
    dY_s = Ynode(i) - Ynode(i-1);
    
    % Interpolate to find the heat conductivity at the faces. Start by
    % finding the interpolation factors
    fn = 0.5*deltaY/dY_n;
    fs = 0.5*deltaY/dY_s;
    % and then compute the face values
    kn = fn*Gamma(i+1) + (1 - fn)*Gamma(i);
    ks = fs*Gamma(i) + (1 - fs)*Gamma(i-1);
    
    % We can now compute the coefficients
    an = kn/dY_n;
    as = ks/dY_s;
    
    % Boundary conditions
    if i == length(Ynode)-1
       an = 0;
    end
    
    ap = an + as - Sp;
    
    % Introduce under-relaxation
    ap = ap/alpha_U;
    Su = Su + ap*(1 - alpha_U)*U(i);
    
    % Put all values in a vector according to the desired output
    
    a = [an as ap Su Sp];
    
end
