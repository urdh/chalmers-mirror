% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the coefficients and sources for a point P given
% coordinates for the nodes (Xnode, Ynode) and faces (Xface, Yface),
% temperature matrix T, and point position in matrix (i, j). And specific
% heat cp, and velocities U, V.
% The output is given as a = [east west north south point]


function a = coefficients(Xface, Yface, Xnode, Ynode, U, V, T, i, j, k, cp)
    
    rho = 1;
    
    % Get the heat conductivity for all nodes
    %gamma = conductivity(T)/cp;
    gamma = k/cp; % for speed
    
    % Compute the cell size
    deltaX = Xface(i, j) - Xface(i, j-1);
    deltaY = Yface(i, j) - Yface(i-1, j);
    
    % Compute distances to neighbor nodes
    dX_e = Xnode(i, j+1) - Xnode(i, j);
    dX_w = Xnode(i, j) - Xnode(i, j-1);
    dY_n = Ynode(i+1, j) - Ynode(i, j);
    dY_s = Ynode(i, j) - Ynode(i-1, j);
    
    % Interpolate to find the heat conductivity at the faces. Start by
    % finding the interpolation factors
    fe = 0.5*deltaX/dX_e;
    fw = 0.5*deltaX/dX_w;
    fn = 0.5*deltaY/dY_n;
    fs = 0.5*deltaY/dY_s;
    % and then compute the face values
    gamma_e = fe*gamma(i, j+1) + (1 - fe)*gamma(i,j);
    gamma_w = fw*gamma(i, j) + (1 - fw)*gamma(i,j-1);
    gamma_n = fn*gamma(i+1, j) + (1 - fn)*gamma(i,j);
    gamma_s = fs*gamma(i, j) + (1 - fs)*gamma(i-1,j);
    
    % Interpolate the velocities at the faces
    u_e = fe*U(i, j+1) + (1 - fe)*U(i,j);
    u_w = fw*U(i, j) + (1 - fw)*U(i,j-1);
    v_n = fn*V(i+1, j) + (1 - fn)*V(i,j);
    v_s = fs*V(i, j) + (1 - fs)*V(i-1,j);

    % Define convection/diffusion constants
    Fe = rho*u_e*deltaY;
    Fw = rho*u_w*deltaY;
    Fn = rho*v_n*deltaX;
    Fs = rho*v_s*deltaX;
    
    De = gamma_e*deltaY/dX_e;
    Dw = gamma_w*deltaY/dX_w;
    Dn = gamma_n*deltaX/dY_n;
    Ds = gamma_s*deltaX/dY_s;
	
    % Compute the Peclet numbers
    Pe_e = Fe/De;
    Pe_w = Fw/Dw;
    Pe_n = Fn/Dn;
    Pe_s = Fs/Ds;

    % Compute the coefficients
    if abs(Pe_e) <= 2
        ae = (De-Fe*fe);
    else
        ae = max([-Fe 0]);
    end
    if abs(Pe_w) <= 2
        aw = (Dw+Fw*(1-fw));
    else
        aw = max([Fw  0]);
    end
    if abs(Pe_n) <= 2
        an = (Dn-Fn*fn);
    else
        an = max([-Fn 0]);
    end
    if abs(Pe_s) <= 2
        as = (Ds+Fs*(1-fs));
    else
        as = max([Fs  0]);
    end
    
    % Set Neumann boundary conditions on boundary 2-4
    if i+1 == size(Ynode, 1)
        an = 0;
    end
    
    if i == 2
        as = 0;
    end
    
    if j+1 == size(Xnode, 1)
        ae = 0;
    end
    
    % Set Neumann boundary condition on the outlet
    %FIXME: Tror ej att vi begöver sätta något här, ty ren upwind gör att
    % aw = 0 iaf.
    if (j == 2 && U(i, j-1) < 0)
        aw = 0;
    end
    
    ap = ae + aw + an + as;
    
    % Put all values in a vector according to the desired output
    a = [ae aw an as ap];
    
end
