% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file is the actual iterative solver, using the Gauss-Seidel 
% iterative method. The function returns a matrix of solutions in every 
% node given the node (Xnode, Ynode) and face coordinates (Xface, Yface)
% as well as the initial guess T_0 and maximum normalized residual epsilon.
% And also a specific heat cp, and velocities U, V.


function [T] = gauss_seidel(Xface, Yface, Xnode, Ynode, U, V, T_0, epsilon, k, cp)
    
    
    % Initialize the temperature matrix
    T = T_0;
    
    % Create some kind of homemade do while-loop to ensure that at least
    % one iteration is done
    not_done = true;
    
    % Count the number of iterations
    numberOfIterations = 0;
    
    while not_done
        
        for i = 2:(size(Ynode, 1) - 1)
            
            for j = 2:(size(Ynode, 2) - 1)
                
                % Get the coefficients with sources 
                % a = [east west north south point]
                a = coefficients(Xface, Yface, Xnode, Ynode, U, V, T, i, j, k, cp);
                
                % Compute the node temperature
                T(i,j) = (a(1)*T(i,j+1) + a(2)*T(i,j-1) + a(3)*T(i+1,j) ...
                    + a(4)*T(i-1,j))/a(5);
            end
            
        end
        
        % Get the normalized residuals
        residuals = residual(Xface, Yface, Xnode, Ynode, U, V, T, k, cp);
        
        % Determine if the convergence criteria is met
        not_done = residuals > epsilon;
        
        numberOfIterations = numberOfIterations + 1;
        
        % Diagnostic, mostly
        if mod(numberOfIterations, 25) == 0
            disp(['Iteration ', num2str(numberOfIterations), ...
                  ' with residual ', num2str(residuals)])
        end
        
    end
    
    % Set correct temperature on "boundary 3" due to implicit boundary
    % condition
    outlet = U(:,1)<0;
    
    T(outlet, 1) = T(outlet, 2);
    T(end, :) = T(end-1, :);
    T(1, :) = T(2, :);
    T(:, end) = T(:, end-1);
    
    disp(['Done after ', num2str(numberOfIterations), ' iterations.'])
    
end
