% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the normalized residuals for one iteration given the
% temperature matrix T. And specific heat cp, and velocities U, V.


function residual = residual(Xface, Yface, Xnode, Ynode, U, V, T, k, cp)
    
    % Initialize
    residual = 0;
    
    for i = 2:(size(Ynode, 1) - 1)
            
            for j = 2:(size(Ynode, 2) - 1)
                
                % Get the coefficients with sources 
                % a = [east west north south point]
                a = coefficients(Xface, Yface, Xnode, Ynode, U, V, T, i, j, k, cp);
                
                % Compute and add the node residual to the sum of residuals
                noderes = abs((a(1)*T(i,j+1) + a(2)*T(i,j-1) + a(3)*T(i+1,j) ...
                    + a(4)*T(i-1,j)) - T(i,j)*a(5));
                
                residual = residual + noderes;
                
            end
            
    end
    
    % Get the total flux into the domain
    nflux = normflux(Ynode, U, T);
    
    % Normalize the residuals with the total flux into the domain
    residual = residual/nflux;
    
end
