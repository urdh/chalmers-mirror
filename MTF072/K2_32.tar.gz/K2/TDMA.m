% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file is the actual iterative solver, using the TDMA 
% iterative method. The function returns a matrix of solutions in every 
% node given the node (Xnode, Ynode) and face coordinates (Xface, Yface)
% as well as the initial guess T_0 and maximum normalized residual epsilon.
% And also a specific heat cp, and velocities U, V.


function [T] = TDMA(Xface, Yface, Xnode, Ynode, U, V, T_0, epsilon, k, cp)
    
    
    % Initialize the temperature matrix
    T = T_0;
    
    % Create some kind of homemade do while-loop to ensure that at least
    % one iteration is done
    not_done = true;
    
    % Count the number of iterations
    numberOfIterations = 0;
    
    while not_done
        
        % Alternate between TDMA in X and Y direction
        if mod(numberOfIterations, 2) == 0
            for i = 2:(size(Ynode, 1) - 1)

                % Initialize P and Q for speed
                P = zeros(1, size(Ynode, 2));
                Q = zeros(1, size(Ynode, 2));

                for j = 2:(size(Ynode, 2) - 1)

                    % Get the coefficients with sources 
                    % a = [east west north south point]
                    coeffs = coefficients(Xface, Yface, Xnode, Ynode, U, V, T, i, j, k, cp);

                    % Define the intermediate coefficients
                    a = coeffs(5);
                    b = coeffs(1);
                    c = coeffs(2);
                    d = coeffs(3)*T(i+1,j) + coeffs(4)*T(i-1,j);

                    % Calculate coefficients P and Q
                    if j == 2
                        P(j) = b/a;
                        Q(j) = (d + c*T(i,1))/a;
                    else
                        P(j) = b/(a - c*P(j-1));
                        Q(j) = (d + c*Q(j-1))/(a - c*P(j-1));
                    end
                end

                % Calculate T using P and Q
                for j = (size(Ynode, 2) - 1):-1:2
                   T(i,j) = P(j)*T(i,j+1) + Q(j);
                end

            end
        else
            for j = 2:(size(Ynode, 2) - 1)
            
                % Initialize P and Q for speed
                P = zeros(1, size(Ynode, 1));
                Q = zeros(1, size(Ynode, 1));

                for i = 2:(size(Ynode, 1) - 1)

                    % Get the coefficients with sources 
                    % a = [east west north south point]
                    coeffs = coefficients(Xface, Yface, Xnode, Ynode, U, V, T, i, j, k, cp);

                    % Define the intermediate coefficients
                    a = coeffs(5);
                    b = coeffs(3);
                    c = coeffs(4);
                    d = coeffs(1)*T(i,j+1) + coeffs(2)*T(i,j-1);

                    % Calculate coefficients P and Q
                    if i == 2
                        P(i) = b/a;
                        Q(i) = (d + c*T(1,j))/a;
                    else
                        P(i) = b/(a - c*P(i-1));
                        Q(i) = (d + c*Q(i-1))/(a - c*P(i-1));
                    end
                end

                % Calculate T using P and Q
                for i = (size(Ynode, 2) - 1):-1:2
                   T(i,j) = P(i)*T(i+1,j) + Q(i);
                end

            end
        end
            
        % Get the normalized residuals
        residuals = residual(Xface, Yface, Xnode, Ynode, U, V, T, k, cp);
        
        % Determine if the convergence criteria is met
        not_done = residuals > epsilon;
        
        numberOfIterations = numberOfIterations + 1;
        
        % Diagnostic, mostly
        if mod(numberOfIterations, 25) == 0
            disp(['Iteration ', num2str(numberOfIterations), ...
                  ' with residual ', num2str(residuals)])
        end
        
    end
    
    % Set correct temperature on "boundary 3" due to implicit boundary
    % condition
    outlet = U(:,1)<0;
    
    T(outlet, 1) = T(outlet, 2);
    T(end, :) = T(end-1, :);
    T(1, :) = T(2, :);
    T(:, end) = T(:, end-1);
    
    disp(['Done after ', num2str(numberOfIterations), ' iterations.'])
    
end
