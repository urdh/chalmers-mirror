% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the heat conductivity in the domain given the
% temperature matrix T.

function k = conductivity(T)
    
    % Compute k according to the given formula
    k = ones(size(T));
    
end
