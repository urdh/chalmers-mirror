% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file is the man file that calls other functions to do its work.

function solver()
    
    clear all
    close all
    clc
    
    % Declare problem variables, and precision
    epsilon = 0.001;
    k = 1;
    cp = 500;
    rho = 1;
    
    % Declare the boundary temperatures
    T1 = 5;
    T_in = 20;
    
    % Load the mesh
    [Xface, Yface] = meshing('./grid2/fine_grid/xc.dat',...
                                './grid2/fine_grid/yc.dat');
    
    % Retrive the node coordinates
    [Xnode, Ynode] = nodes(Xface, Yface);
    
    % Get the number of nodes in each direction
    [ny, nx] = size(Xnode);
    
    % Get the velocity field
    [U, V] = velocityretrieve('./grid2/fine_grid/u.dat',...
                                './grid2/fine_grid/v.dat', nx, ny);
    
    % Make an initial guess of the temperatures, with correct temperatures
    % at the boundaries
    T_0 = initial(Xnode, T1, T_in, U);
    
%     % Solve for the temperatures (Gauss-Seidel)
%     tic
%     disp(['Running Gauss-Seidel solver...'])
%     T_gauss = gauss_seidel(Xface, Yface, Xnode, Ynode, U, V, T_0, epsilon, k*ones(size(T_0)), cp);
%     toc
%     
%     % Plot the solution
%     figure(1)
%     suptitle('Temperature field using Gauss-Seidel solver')
%     subplot(1,2,1)
%         surf(Xnode, Ynode, T_gauss)
%         axis([0 3 0 2 0 20])
%         xlabel('x [m]')
%         ylabel('y [m]')
%         zlabel('Temperature [^\circ C]')
%         
%     subplot(1,2,2)
%         [ch,ch] = contourf(Xnode, Ynode, T_gauss, 50);
%         set(ch, 'edgecolor', 'none')
%         colorbar
%     matlab2tikz('Figures/gauss_seidel.tikz',...
%                    'height', '5cm', 'width', '5cm');    
%     
    % Solve for the temperatures (TDMA)
    tic
    disp(['Running TDMA solver...'])
    T_TDMA = TDMA(Xface, Yface, Xnode, Ynode, U, V, T_0, epsilon, k*ones(size(T_0)), cp);
    toc
%     
%     % Plot the solution
%     figure(2)
%     suptitle('Temperature field using TDMA solver')
%     subplot(1,2,1)
%         surf(Xnode, Ynode, T_TDMA)
%         axis([0 3 0 2 0 20])
%         xlabel('x [m]')
%         ylabel('y [m]')
%         zlabel('Temperature [^\circ C]')
%         
%     subplot(1,2,2)
%         [ch,ch] = contourf(Xnode, Ynode, T_TDMA, 50);
%         set(ch, 'edgecolor', 'none')
%         colorbar
        
%     matlab2tikz('Figures/Vary-k/k_big.tikz',...
%                     'height', '5cm', 'width', '5cm');
    
%     % Compare solutions
%     T_diff = abs(T_TDMA - T_gauss);
%     figure(3)
%     [ch,ch] = contourf(Xnode, Ynode, T_diff, 50);
%     set(ch, 'edgecolor', 'none')
%     colorbar
%     %title('Difference between Gauss-Seidel and TDMA')
%     xlabel('x [m]')
%     ylabel('y [m]')
%     
%     matlab2tikz('Figures/difference.tikz',...
%                     'height', '5cm', 'width', '5cm');
%     
%     % Plot the fluxes
%     [qx, qy] = flux(Xnode, Ynode, U, V, T_TDMA, cp, rho);
%     figure(4)
%     quiver(Xnode, Ynode, qx, qy)
%     
    % Plot the fluxes at Dirichlet boundary
    [qe, qw, qn, qs, q_tot] = influx(Xface, Yface, Xnode, Ynode, U, V, T_TDMA, cp, rho);
%     figure(5)
%     
%     subplot(1,2,1)
%         plot(Ynode(:,1), qw)
%         grid on
%         xlabel('y [m]')
%         ylabel('Heat flux [W]')
%         
%     subplot(1,2,2)
%         plot(Ynode(:,1), qw)
%         axis([0 2 -300 0])
%         grid on
%         xlabel('y [m]')
%         ylabel('Heat flux [W]')
%         
%     matlab2tikz('Figures/boundary_flux.tikz',...
%                     'height', '5cm', 'width', '5cm');
%     
%     % Plot temperature on y = H boundary
%     figure(6)
%     plot(Xnode(end, :), T_TDMA(end, :))
%     title('Temperature at north boundary')
%     xlabel('x [m]')
%     ylabel('Temperature [^\circ C]')
%     matlab2tikz('Figures/Boundary-values/heat-north.tikz',...
%                     'height', '5cm', 'width', '5cm');
    
    
    disp('Normalized net flux (positive sign into domain):')
    disp(q_tot)
    
end
