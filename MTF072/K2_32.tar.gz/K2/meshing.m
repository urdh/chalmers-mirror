% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file loads the mesh and writes it as we want.
% All data needed is the path to the files containing the mesh.

function [X, Y] = meshing(filename_x, filename_y)
    
    % Read the given mesh
    x = load(filename_x);
    y = load(filename_y);
    
    % Create the mesh as we want it
    [X, Y] = meshgrid(x, y);
end
