% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k1
% Emil Ljungskog & Simon Sigurdhsson

% This file generates the node coordinates given the matrices for the
% coordinates of the faces Xface and Yface from meshing.m

function [Xnode, Ynode] = nodes(Xface, Yface)
    
    % Initialize the two matrices and account for the nodes at the
    % boundaries
    Xnode = zeros(size(Xface) + 1);
    Ynode = zeros(size(Yface) + 1);
    
    % Compute the node coordinates for the inner nodes
    for i = 2:size(Xface, 1)
        
        for j = 2:size(Yface, 2)
            
            Xnode(i, j) = (Xface(i, j) + Xface(i, j-1))/2;
            Ynode(i, j) = (Yface(i, j) + Yface(i-1, j))/2;
            
        end
        
    end
    
    % Fix the boundary nodes in a rather ugly way by just copying the
    % correct values from other rows/columns and the face matrices
    Xnode(1,:) = Xnode(2,:);
    Xnode(end,:) = Xnode(end-1,:);
    Xnode(:,end) = ones(size(Xnode(:,end)))*Xface(end);
    
    Ynode(:,1) = Ynode(:,2);
    Ynode(:,end) = Ynode(:,end-1);
    Ynode(end,:) = ones(size(Ynode(end,:)))*Yface(end);
    
end
