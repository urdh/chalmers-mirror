% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file generates the initial guess for the temperatures in the nodes,
% with correct temperatures at the boundaries and the inlet. T1 is the
% temperature on x = 0 and T_in is the temperature at the inlet.

function [T_0] = initial(Xnode, T1, T_in, U)
    
    % Guess zero temperature
    T_0 = zeros(size(Xnode));
    
    % Fix the prescribed boundary temperatures
    wall = abs(U(:,1))<1e-6;
    inlet = U(:,1)>1e-6;
    
    T_0(inlet, 1) = T_in;
    T_0(wall, 1) = T1;
    
end
