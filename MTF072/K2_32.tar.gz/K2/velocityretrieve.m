% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file loads the velocities and store them in a matrix of the same
% size as the mesh.
% All data needed is the path to the files containing the velocities and
% the number of nodes in each direction.

function [U, V] = velocityretrieve(filename_u, filename_v, nx, ny)
    
    % Read the given parameters
    u = load(filename_u);
    U = reshape(u,nx,ny);
    
    v = load(filename_v);
    V = reshape(v,nx,ny);
    
end