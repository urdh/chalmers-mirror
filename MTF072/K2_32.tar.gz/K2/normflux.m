% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the inlet flux used in residual normalization.


function flux = normflux(Ynode, U, T)
    % Get the total flux into the domain
    inlet = U(:,1)>1e-6;
    outlet = U(:,1)<0;
    rho = 1;
    deltaT = abs(mean(T(outlet,2)) - mean(T(inlet,1)));
    h = max(Ynode(inlet,1)) - min(Ynode(inlet,1));
    inletmassflux = rho*mean(U(inlet,1))*h;
    flux = inletmassflux*deltaT;
end