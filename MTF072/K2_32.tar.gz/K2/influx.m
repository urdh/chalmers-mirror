% MTF072 - Computational Fluid Dynamics
% Autumn 2012
% Task k2
% Emil Ljungskog & Simon Sigurdhsson

% This file computes the total flux in and out of the domain, as well as
% the fluxes at the boundaries.

function [qe qw qn qs q_tot] = influx(Xface, Yface, Xnode, Ynode, U, V, T, cp, rho)
    
    % Get the flux for the entire domain
    [qx qy] = flux(Xnode, Ynode, U, V, T, cp, rho);
    
    % Extract flux at the boundary nodes
    qe = qx(:,end);
    qw = qx(:,1  );
    qn = qy(end,:);
    qs = qy(1,:  );
    
    % Calculate the total boundary flux by "integration" over the boundary.
    E = sum(qe(2:end-1).*diff(Yface(:, end)));
    W = sum(qw(2:end-1).*diff(Yface(:, 1)));
    N = sum(qn(2:end-1).*diff(Xface(end, :)));
    S = sum(qs(2:end-1).*diff(Xface(1, :)));
    
    q_tot = E + W + N + S;
    
    % Normalize q_tot
    
    inlet = U(:,1)>1e-6;
    outlet = U(:,1)<0;
    Tin = mean(T(outlet,2));
    Tut = mean(T(inlet,1 ));
    hin = max(Ynode(inlet,1)) - min(Ynode(inlet,1));
    hut = max(Ynode(outlet,1)) - min(Ynode(outlet,1));
    inletflux =  rho*mean(U(inlet,1 ))*hin*Tin*cp;
    outletflux = rho*mean(U(outlet,2))*hut*Tut*cp;
    nflux = abs(inletflux - outletflux);
    
    q_tot = q_tot/nflux;
end
    