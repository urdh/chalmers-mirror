import java.util.Scanner;
// Grupp 2, Simon Sigurdhsson & Alexander Andersson

public class Goldbach{
    public static int hittaKombinationer(int number){
		if(number < 2 || number%2 == 1) return 0;
		int half = number/2;
		int combos = 0;
		// Testa endast upp till halva talet, allt annat �r dubletter.
		for(int i=2;i<=half;i++){
		    if(primtal(i) && primtal(number-i)){
				combos++;
				System.out.println("Komination funnen: "+i+"+"+(number-i));
		    }
		}
		return combos;
    }

    public static boolean primtal(int number){
	// Mindre �n ett ger inget primtal
	if(number <= 1){
	    return false;
	}
	// Tv� och tre �r primtal
	if(number == 2 || number == 3){
	    return true;
	}
	// Testa delbarhet med 2 & 3
	if(number%2 == 0 || number%3 == 0){
	    return false;
	}
	// Testa endast tal av formen 6k�1 d� alla primtal �r av denna form
	// Delar vi med 6k�1 s� delar vi allts� garanterat med alla
	// primtal < sqrt(n)
	// Testa upp till roten ur talet, det g�r snabbare.
	double sqrt = Math.sqrt(number);
		for(int i=6;i<=(sqrt+1);i=i+6){
		    if(number%(i-1) == 0 || number%(i+1) == 0){
			return false;
		    }
		}
		return true;
    }

    public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		int indata = 0;
		do{
		    try{
			System.out.print("Mata in ett j�mnt tal (>2): ");
			indata = in.nextInt();
			// Kolla om inmatat tal �r valid input
			if(indata%2 == 0 && indata>2){
			    System.out.println("Antal kombinationer: "
					       + hittaKombinationer(indata));
			// Oj, talet �r felaktigt men st�rre �n tv�
			}else if(indata>2){
			    System.out.println("Endast j�mna tal!");
			}
		    // F�nga exceptions som nextInt() kastar om inmatningen �r felaktig
		    }catch(java.util.InputMismatchException e){
			System.out.println("Felaktig inmatning");
			indata = 3;
			in.next();
		    }
		}while(indata>2);
    }
}