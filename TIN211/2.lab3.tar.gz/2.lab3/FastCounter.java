// Grupp 2, Simon Sigurdhsson & Alexander Andersson
public class FastCounter extends Counter{
    private int x=1;
    public FastCounter(int x){
		super();
		this.x=x;
    }
	public FastCounter(int x, int max){
		super(max);
		this.x=x;
	}
    public void upMany(){
		for(int i=0;i<x;i++){
		    up();
		}
    }
    public void downMany(){
		for(int i=0;i<x;i++){
		    down();
		}
    }
    public void upMany(int steg){
		for(int i=0;i<steg;i++){
		    up();
		}
    }
    public void downMany(int steg){
		for(int i=0;i<steg;i++){
		    down();
		}
    }
}