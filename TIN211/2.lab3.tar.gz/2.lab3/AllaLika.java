// Grupp 2, Simon Sigurdhsson & Alexander Andersson
public class AllaLika{
    public static void main(String[] args){
		int[][] m={null,null,{1,3,4,3,2},{2,4,4,4},null};
		print(m);
		System.out.println(allRowSumsEqual(m));
		int[][] k={null,{2,4,6,4,3},null,{6,4,6,3}};
		print(k);
		System.out.println(allRowSumsEqual(k));
		int[][] e = {null, null, null};
		print(e);
		System.out.println(allRowSumsEqual(e));
		int[][] f = {};
		print(f);
		System.out.println(allRowSumsEqual(f));
		int[][] g = {{}};
		print(g);
		System.out.println(allRowSumsEqual(g));
		int[][] h = {{1,2,3}};
		print(h);
		System.out.println(allRowSumsEqual(h));
		int[][] i = {{1},{2},{3}};
		print(i);
		System.out.println(allRowSumsEqual(i));
		int[][] j = {{0}};
		print(j);
		System.out.println(allRowSumsEqual(j));		
    }

    static boolean allRowSumsEqual(int[][] m){
		if( m == null || m.length == 0){
		    return true;
		}

		int l=0;
		while(m[l] == null && l < m.length-1){
		    l++;
		}
		if(m[l]==null)
			return true;
		int firstvalue=rowSum(m[l]);

		for(int i=l;i<m.length;i++){
		    if( m[i] != null && rowSum(m[i]) != firstvalue ){
				return false;
		    }
		}
		return true;
    }

    static int rowSum(int[] v){
		if( v == null )
		    throw new NullPointerException();
		int value=0;
		for(int i=0;i<v.length;i++){
		    value=value+v[i];
		}
		return value;
    }

    static void print(int[][] m) {
		int summa;
		if( m == null || m.length == 0 ){
		    System.out.println("[-]");
		}else{
		    for(int i=0;i<m.length;i++){
				if ( m[i] != null ){
				    summa=0;
				    System.out.print("[ ");
				    for(int j=0;j<m[i].length;j++) {
					System.out.print(m[i][j] + " ");
					summa=summa+m[i][j];
				    }
				    System.out.println("] = " + summa);
				}
				else {
				    System.out.println("[-]");
				}
		    }
		}
    }
}