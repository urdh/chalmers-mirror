import java.util.Random;
// Grupp 2, Simon Sigurdhsson & Alexander Andersson

public class TestaCounter{
    static public void setRandomCounterValue(Counter c){
		Random rand = new Random();
		c.setCounter(Math.abs(rand.nextInt()));
    }
    static public void main(String[] args){
		Counter c1 = new Counter();
		Counter c2 = new Counter();
		System.out.println("Setting c1 to 12 and c2 to 59.");
		c1.setCounter(12);
		c2.setCounter(59);
		System.out.println("c1 = "+c1.whatIsCounter());
		System.out.println("c2 = "+c2.whatIsCounter());
		System.out.println("Incrementing c2 and resetting c1.");
		c2.up();
		c1.reset();
		System.out.println("c1 = "+c1.whatIsCounter());
		System.out.println("c2 = "+c2.whatIsCounter());
		System.out.println("Decrementing c1, incrementing c2.");
		c2.up();
		c1.down();
		System.out.println("c1 = "+c1.whatIsCounter());
		System.out.println("c2 = "+c2.whatIsCounter());
		System.out.println("Number of counters is "+Counter.nbrOfCounters());
		System.out.println("Creating counter c3 with max = 9");
		Counter c3 = new Counter(9);
		System.out.println("Setting c3 to 9");
		c3.setCounter(9);
		System.out.println("c3 = "+c3.whatIsCounter());
		System.out.println("Incrementing c3");
		c3.up();
		System.out.println("c3 = "+c3.whatIsCounter());
		System.out.println("Testing c1.equals(c3): " + c1.equals(c3));
		System.out.println("Decrementing c2");
		c2.down();
		System.out.println("c2 = "+c2.whatIsCounter());
		System.out.println("Testing c3.equals(c2): " + c3.equals(c2));
		System.out.println("Testing c2.toString()...");
		System.out.println(c2.toString());
		System.out.println("Field full of counters!");
		Counter[] cf = new Counter[5];
		Random rand = new Random();
		int cfSize = cf.length;
		for(int i=0;i<cfSize;i++){
		    cf[i] = new Counter();
		    cf[i].setCounter(rand.nextInt(59));
		    System.out.println("cf["+i+"] = "+cf[i].whatIsCounter());
		}
		System.out.println("Randomly incrementing or decrementing cf:");
		for(int i=0;i<cfSize;i++){
		    if(rand.nextBoolean()){
			System.out.println("Incrementing cf["+i+"]...");
			cf[i].up();
		    }else{
			System.out.println("Decrementing cf["+i+"]...");
			cf[i].down();
		    }
		}
		System.out.println("Field now looks like this:");
		for(int i=0;i<cfSize;i++){
		    System.out.println("cf["+i+"] = "+cf[i].whatIsCounter());
		}
		System.out.println("Doing setRandomCounterValue(c2)");
		setRandomCounterValue(c2);
		System.out.println("c2 = " + c2.whatIsCounter());
		System.out.println("Creating a FastCounter, cs with up 15");
		FastCounter cs = new FastCounter(15);
		cs.setCounter(34);
		System.out.println("cs = " + cs.whatIsCounter());
		System.out.println("Doing cs.upMany()");
		cs.upMany();
		System.out.println("cs = " + cs.whatIsCounter());
		System.out.println("Doing cs.downMany()");
		cs.downMany();
		System.out.println("cs = " + cs.whatIsCounter());
    }
}