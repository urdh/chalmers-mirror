/**
 * A Counter, with the ability to wrap and set the max value
 * 
 * @author Simon Sigurdhsson & Alexander Andersson, Grupp 2
 * @version 1.0
 **/
public class Counter{
    private int wrapNum = 0;
    private int count = 0;
    static private int nbrOfC;
    /**
     * Constructor taking no parameters, setting the default max value of 59
     **/
    public Counter(){
		this(59);
    }
    /**
     * Constructor setting the max value
	 * Throws on non-positive integers.
     * @param max maximum count number
     **/
    public Counter(int max){
		if(max<1) throw new IllegalArgumentException();
		this.wrapNum = max+1;
		nbrOfC++;
    }
    /**
     * Increment counter by one
     **/
    public void up(){
		count = (count+1)%wrapNum;
    }
    /**
     * Decrement counter by one
     **/
    public void down(){
		count--;
		if(count < 0) count = wrapNum-1;
    }
    /**
     * Reset counter to zero
     **/
    public void reset(){
		count = 0;
    }
    /**
     * Set counter to a value.
	 * Throws on non-positive integers, wraps on too large numbers.
     * @param t value to set counter to
     **/
    public void setCounter(int t){
		if(t<0) throw new IllegalArgumentException();
		count = t%wrapNum;
    }
    /**
     * Get counter value
     * @return counter value
     **/
    public int whatIsCounter(){
		return count;
    }
    /**
     * Get number of counters
     * @return number of counters
     **/
    static public int nbrOfCounters(){
		return nbrOfC;
    }
    /**
     * Does this counter equal another one?
     * @param rhs Object to compare to
     * @return true if they equal
     **/
    public boolean equals(Object rhs){
		if(rhs == this) return true;
		if(rhs == null) return false;
		if(rhs.getClass() != this.getClass()) return false;
		Counter counter = (Counter)rhs;
		return (counter.whatIsCounter() == count);
    }
    /**
     * Return a string
     * @return a string
     **/
    public String toString(){
		return "Counter value: " + count;
    }
}