// Grupp 2, Simon Sigurdhsson & Alexander Andersson

public class Strings{
    public static void main(String[] args){
	String originalText = "This is a Test";
	String lowcaseText = originalText.toLowerCase();
	System.out.println(lowcaseText);
	String bigTestString = lowcaseText.toUpperCase();
	System.out.println(bigTestString);
    }
}