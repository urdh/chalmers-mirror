Grupp 2, Simon Sigurdhsson & Alexander Andersson

===============   DEL A   ===============
1.(R) The if statement is used to implement a decision. The if statement has two
1.1 - 6 asterisks
 .2 - 15 asterisks
 .3 - 3 asterisks
 .4 - 1 asterisk

3.(R) Formulate the following conditions for the Rectangle object r:
3.1 - r.getWidth() <= 10
 .2 - (r.getWidth() * r.getHeight()) == 100

7.(R) What are the results when point1 = (4, 2.5) and point2 = (3, 1.5)?
7.  "The slope of the line is 1.0" is printed.

10.(R) According to the following program, what color results when using the
10.1 - PURPLE
  .2 - YELLOW
  .3 - BLACK

12.(R) Values of year larger tha 3000 cause the following loop to terminate
12.  - "Another -1 years to the millennium."
       nyear is increased by one until it equals millennium. The
       difference between nyear and year is calculated and displayed.
       The loop terminates even though it shouldn't, because the value of nyear
       increases until it reaches the maximum value of an int, and then
       overflows and starts over at the minimum value of an int. It then
       increases in value until it reaches millenium.

16.(R) Convert the while loop to a for loop.
16.  - See "FirstPowOf2.java"

===============   DEL B   ==============
2.(R) Now, add the following two lines to the program you created on the previous
2.   - It will print "this is a test", then "THIS IS A TEST", which also implies
       that we didn't get the original string back. This is expected.
       (See "Strings.java")

10.(R) Modify your program and change the line where you create the second rect
10.  - Output is:
       java.awt.Rectangle[x=-10,y=-20,width=120,height=90]
       java.awt.Rectangle[x=-10,y=-20,width=120,height=90]
       
       This is because r2 = r1 only copies the reference, the two references will
       still refer to the same data. (See "RectangleTester.java")

11.(R) Consider the following program:
11.  - Output is 150.0 and 3000.0, which is to be expected since we actually copy
       the value of the variable to a new variable. In the previous case, the
       same thing happened, but with the references. We copied the value of the
       reference. But this means the references refer to the same location, so
       when we modify the data they refer to, it doesn't matter what reference we
       use. We are still modifying the same data.
       (See "NumberVariablesTester.java")
