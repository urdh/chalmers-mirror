// Grupp 2, Simon Sigurdhsson & Alexander Andersson   
public interface Function{
    public double f(double x);
    public String toString();
}