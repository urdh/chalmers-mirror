// Grupp 2, Simon Sigurdhsson & Alexander Andersson   

public class Uppg1{
    static public void main(String[] args){
	try{
	    MyFunc func = new MyFunc();
	    double rot = Rot.sekant(func, 0, 1, 1.0e-16);
	    System.out.println("Found one root for <" + func +
			       ">, at x = " + rot);
	}catch(ArithmeticException e){
	    System.out.println(e.getMessage());
	}
    }
}