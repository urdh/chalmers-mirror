import java.lang.Math;

// Grupp 2, Simon Sigurdhsson & Alexander Andersson
public class FuncPlotter extends PlotFunction{
    public double func(double x){
	return Math.sin(x) * x * x - Math.exp(x) + 3;
    }

    public static void main(String[] args){
	FuncPlotter a = new FuncPlotter();
    }
}