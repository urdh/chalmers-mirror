import java.lang.Math;

// Grupp 2, Simon Sigurdhsson & Alexander Andersson   
public class Rot{
    static public double sekant(Function f, double nedre, double ovre, double eps){
	try{
	    double fovre=f.f(ovre);                                         
	    double fnedre=f.f(nedre);                                       
	    double x = (ovre*fnedre-nedre*fovre)/(fnedre-fovre);   
	    if ( Math.abs(x-ovre) < eps )                                   
		return x;                                               
	    if ( Math.abs(x-nedre) < eps )                                  
		return x;                                               
	    double ffx=f.f(x);
	    if(ffx == 0) return x;
	    return (ffx<0 ) ? sekant(f,x,ovre,eps) : sekant(f,nedre,x,eps);
	}catch(StackOverflowError e){
	    throw new ArithmeticException("Function has no roots in interval");
	}
    }
}