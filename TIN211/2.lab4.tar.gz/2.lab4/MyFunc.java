// Grupp 2, Simon Sigurdhsson & Alexander Andersson   

public class MyFunc implements Function{
    public double f(double x){
	return x*x - 0.6;
    }

    public String toString(){
	return "x^2-0,6";
    }
}