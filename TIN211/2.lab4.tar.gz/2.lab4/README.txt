Grupp 2, Simon Sigurdhsson & Alexander Andersson

Till uppgift 1 h�r filerna Function.java, MyFunc.java, Rot.java och Uppg1.java

Till uppgift 2a/b h�r filen PlotFunction.java

Till uppgift 2c h�r FuncPlotter.java

Observera att de enda filerna som �r meningsfulla att k�ra �r Uppg1.java och
  FuncPlotter.java, resten �r abstrakta klasser, interface och annat.
