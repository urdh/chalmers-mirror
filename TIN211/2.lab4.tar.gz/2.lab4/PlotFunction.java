import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Grupp 2, Simon Sigurdhsson & Alexander Andersson   
public abstract class PlotFunction extends JFrame implements ActionListener{
    private JTextField plotcolor;                                             
    private Rityta plot;
    private final int WIDTH = 500;
    private final int HEIGHT = 380;  
    private enum Buttons{ RED, BLUE, BLACK, QUIT };

    public PlotFunction(){
	JPanel buttpanel = new JPanel(new GridLayout(4, 1));

	JButton redbutt = new JButton("Red");
	JButton bluebutt = new JButton("Blue");
	JButton blackbutt = new JButton("Black");
	JButton quitbutt = new JButton("Quit");

	redbutt.setActionCommand(Buttons.RED.toString());
	bluebutt.setActionCommand(Buttons.BLUE.toString());
	blackbutt.setActionCommand(Buttons.BLACK.toString());
	quitbutt.setActionCommand(Buttons.QUIT.toString());

	redbutt.addActionListener(this);
	bluebutt.addActionListener(this);
	blackbutt.addActionListener(this);
	quitbutt.addActionListener(this);

	buttpanel.add(redbutt);
	buttpanel.add(bluebutt);
	buttpanel.add(blackbutt);
	buttpanel.add(quitbutt);
	buttpanel.setPreferredSize(new Dimension(75, HEIGHT+20));

	JPanel plotpanel = new JPanel(new BorderLayout());

	plot = new Rityta(4, 4);
	plot.setBackground(Color.WHITE);
	plot.setPreferredSize(new Dimension(WIDTH, HEIGHT));
	plot.setColor(Color.BLUE);
	plotpanel.add(plot);
	
      	plotcolor = new JTextField("Blue");
	plotcolor.setPreferredSize(new Dimension(WIDTH, 20));
	plotcolor.setEditable(false);
	plotpanel.add(plotcolor, BorderLayout.SOUTH);

	setLayout(new BorderLayout());                   
	add(buttpanel, BorderLayout.WEST);                    
        add(plotpanel);
	pack();

	setTitle("En funktionsplotter");
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setVisible(true);
    }

    abstract public double func(double x);

    public void actionPerformed(ActionEvent e){
	try{
	    if(e.getSource() instanceof JButton){
		switch(Buttons.valueOf(e.getActionCommand())){
		    case RED:
			plotcolor.setText(((JButton)e.getSource()).getText());
			plot.setColor(Color.RED);              
			plot.repaint();      
			break; 
		    case BLUE:
			plotcolor.setText(((JButton)e.getSource()).getText());
			plot.setColor(Color.BLUE);                         
			plot.repaint();         
			break; 
		    case BLACK:
			plotcolor.setText(((JButton)e.getSource()).getText());
			plot.setColor(Color.BLACK);
			plot.repaint();
			break;
		    case QUIT:
		    default:
    		        System.exit(0);
		}
	    }
	}catch(IllegalArgumentException exc){
	    System.err.println("Non-existent actioncommand received");
	}catch(Exception exc){
	    System.err.println("Something undefined occured.");
	}
    }

    public class Rityta extends JPanel{               
	private int xSkala;                              
	private int ySkala;                                 
	Color myColor = Color.BLUE;                
                                                   
	public Rityta(int xSkala, int ySkala){
	    this.xSkala = xSkala;                            
	    this.ySkala = ySkala;                            
	}                                                  
                                                           
	public void setColor(Color c){                        
	    myColor = c;                                     
	} 
                                                  
	private void drawCoordinates(Graphics g){           
	    Color actualColor = g.getColor();               
	    int width = this.getWidth();                   
	    int height = this.getHeight();                   
	    int xOrigo = width/2;                            
	    int yOrigo = height/2;                          
	    int xRatio = width/(xSkala*2+1);                 
	    int yRatio = height/(ySkala*2+1);                
                                                          
	    g.setColor(Color.black);                        
	    g.drawLine(0, yOrigo, width, yOrigo);          
	    g.drawLine(xOrigo, 0, xOrigo, height);           
	    g.setFont(new Font("Monospaced", Font.PLAIN, 10));
            
	    for(int i = -xSkala; i <= xSkala; i++){           
		if(i == 0) i++;                                
		g.drawString(Integer.toString(i),
			     xOrigo+xRatio*i, yOrigo + 13);
		g.drawLine(xOrigo+xRatio*i, yOrigo-2,
			   xOrigo+xRatio*i, yOrigo+2);
	    }          
	    for(int i = -ySkala; i <= ySkala; i++){
		if(i == 0) i++;  
		g.drawString(Integer.toString(-i),
			     xOrigo + 13, yOrigo+yRatio*i);
		g.drawLine(xOrigo-2, yOrigo+yRatio*i,
			   xOrigo+2, yOrigo+yRatio*i);
	    }                    
	    g.setColor(actualColor);    
	}
                                                        
	private void plotFunction(Graphics g){
		Color actualColor = g.getColor();                          
		int width = this.getWidth();                              
		int height = this.getHeight();                            
		int xOrigo = width/2;                                    
		int yOrigo = height/2;                                  
		int xRatio = width/(xSkala*2+1);                     
		int yRatio = height/(ySkala*2+1); 

		g.setColor(this.myColor);
 
		for(int x = 0; x < this.getWidth(); x++){
		    double rx = (x - xOrigo)/(double)xRatio;
		    double ry = func(rx);
		    int y = (int)(yOrigo - ry*yRatio);
		    g.drawOval(x, y, 1, 1);
		}
		g.setColor(actualColor);
	}
                                                 
	public void paintComponent(Graphics g){  
	    super.paintComponent(g);     
	    drawCoordinates(g);         
	    plotFunction(g);             
	}      
    }    
}
