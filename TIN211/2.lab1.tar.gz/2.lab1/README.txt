Grupp 2 - Simon Sigurdhsson & Alexander Andersson

HelloWorld.java
README.txt


A.1. "cd" eller "cd ~" 
  3. "ls -l"
     Vad �r "ls -l"?(Jeopardyreferens)
     R�ttigheter, Antal h�rda l�nkar, �gare, storlek, skapad, filnamn(eller pekare)
     1. fil, �garen f�r skriva. Alla f�r l�sa filen, men ingen kan exekvera den.
     2.	fil, �garen f�r skriva. Alla f�r l�sa och exekvera filen.
     3. katalog, alla f�r skriva till och l�sa katalogen samt g� in i katalogen

     �garen har fulla r�ttigheter, gruppen f�r l�sa och g� in i katalogen.
     �vriga har inga r�ttigheter.
     
  4. �garen har fulla r�ttigheter, ingen annan har n�gra r�ttigheter.

  5. �garen har l�s- & skrivr�ttigheter, gruppen har l�sr�ttigheter.

B.8.a.
HelloWorld.java:1: '{' expected
public class HelloWorld 
                       ^
1 error
 
    b.
HelloWorld.java:6: reached end of file while parsing
    }
     ^
1 error

    c. Kompilatorn ger inget fel, men vid k�rning f�r man felmeddelandet "Main method not public."

    d. Kompilatorn ger inget fel, men vid k�rning f�r man felmeddelandet:
Exception in thread "main" java.lang.NoSuchMethodError: main

    e.
HelloWorld.java:4: <identifier> expected
    public satic void main(String[] args) {
                ^
HelloWorld.java:4: invalid method declaration; return type required
    public satic void main(String[] args) {
                      ^
2 errors
