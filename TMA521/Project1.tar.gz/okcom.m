% TMA521 - Large scale optimization
% Spring 2013
% Project 1, tasks 1 & 2
% Simon Sigurdhsson

function [ ok, newnl ] = okcom( pi, k, com, nl )
%OKCOM Eliminates paths from com/nl if their cost is large.
%   The okcom function, which contains code from page 6 of
%   the project description, calculates the cost of each path
%   in com/nl, adding the path to ok/newnl if the cost is less
%   than one.
    last = 0;
    ok = zeros(k,2);
    newnl = [];
    for i = 1:k
        first = last+1;
        slask = find(nl(last+1:length(nl)) == com(i,1));
        last = slask(1)+first-1;
        if sum(pi(nl(first:last))) < 1
            ok(i,:) = com(i,:);
            newnl = [newnl; nl(first:last)];
        end
    end
end

