% TMA521 - Large scale optimization
% Spring 2013
% Project 1, tasks 1 & 2
% Simon Sigurdhsson

function [ xij, xtlsl ] = getxij( dimX, dimY, k, com, nl, kok )
%GETXIJ Calculate x_{ijl} and x_{t_{l}s_{l}l} matrices
%   The getxij function takes the output of gsp and transforms it  
%   into the actual problem variables x_{ijl} and x_{t_{l}s_{l}l},
%   making it much easier to calculate the dual value, subgradient
%   direction and step length required by the subgradient algorithm.
    % To begin with, a couple of local variables are defined.
    maxij = dimX*dimY*2;         % The number of nodes in the problem
    xij = zeros(maxij, maxij, k);% Output matrix, preallocated
    xtlsl = zeros(1, 1, k);      % Output matrix, preallocated
    tempnl = nl;                 % Copy of nl, will be modified in loop
    % Now, for all the "ok" paths in com/nl, we set the appropriate
    % elements of the output matrices to 1 (remember that they are
    % initialized to 0).
    for i=kok'
        % First, the part of nl containing the ith path is found.
        % It is assumed that the paths in nl have the same order as 
        % the corresponding path endpoints in com, but that the path
        % is stored "backwards".
        % First, we extract the endpoints.
        sn = com(i,1); en = com(i,2);
        % Then, we extract the path corresponding to those endpoints,
        % assuming that the path is the next one in nl (i.e. the first
        % one in tempnl, in which we discard each path after finding it).
        thisnl = tempnl(1:find(tempnl == sn));
        % Discard the path we just found from tempnl.
        tempnl = tempnl((find(tempnl == sn)+1):end);
        % Now, we set all the appropriate elements of x_{ijl} (with l=i)
        % to one. Since the path is backwards and the matrix is used as
        % x_{jil},for each element j in thisnl except the last, we set 
        % xij(j, j+1, i) to one. This is done using sub2ind, since just
        % inserting the vectors with ordinary subscript indexing sets
        % entire blocks of the matrix (which of course is incorrect).
        xij(sub2ind(size(xij),thisnl(1:end-1),thisnl(2:end),i*ones(length(thisnl)-1,1))) = 1;
        % Finally, we set x_{t_{l}s_{l}l} to one, since this path
        % obviously forms a connection.
        xtlsl(1,1,i) = 1;
      end
end

