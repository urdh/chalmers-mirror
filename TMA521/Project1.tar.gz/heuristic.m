% TMA521 - Large scale optimization
% Spring 2013
% Project 1, task 2
% Simon Sigurdhsson

% This is the primal feasibility heuristic written for task 2, and it 
% is explained further in the report.

function [ ncom, nnl ] = heuristic( dimX, dimY, pi, ~, com, nl)
%HEURISTIC Finds a primal feasible solution given a Lagrangian dual solution
%   This heuristic, explained further by the report, basically transforms
%   a dual solution to a primal feasible solution by re-routing and/or
%   discarding paths from the dual solution. It is polynomial in the number
%   of nodes of the problem (in fact, O(n^2)), and will always terminate with
%   a feasible (but potentially very bad) solution.
    % First, we save the input variables since we'll be changing them a bit. 
    nnl = nl; ncom = com; opi = pi;
    % Now, we find the number of times each node has been used by a path.
    % Call this number 0<=n_i<=k. It is found by simply iterating over each
    % node and setting n_j to the number of times that node occurs in nl.
    nodeusage = zeros(size(pi));
    for i=1:length(nodeusage)
        nodeusage(i) = length(find(nl == i));
    end
    % If solution has no overused nodes, i.e. n_i<2 for all i, the solution
    % primal feasible since all paths are vertex disjoint. In that case, we
    % return the input solution as our primal feasible solution.
    if (max(nodeusage) < 2)
        return
    end
    % If we have overused/infeasible nodes, we save all of them in a vector
    % in order to iterate over them. We want to return a solution for which
    % length(infeasiblenodes) = 0.
    infeasiblenodes = find(nodeusage >= 2);
    % While infeasiblenodes isn't empty (i.e. its length isn't 0), we eliminate
    % paths passing through nodes found in the list.
    while(~isempty(infeasiblenodes))
        % For every infeasible node, we try to either replace a path with a
        % new one, or simply discard it.
        for i=1:length(infeasiblenodes)
            % First, we reset the nl, com and pi variables by copying the
            % com and nl variables from the current "state" (i.e. the current
            % output variables), and pi from the input variable.
            nl = nnl; com = ncom; pi = opi;          
            % We find the first path that passes through the first
            % infeasible node in our list. This code is based on the code
            % in okcom.m, and functions like it. The result is a pair of
            % variables first,last containing the positions of the path in
            % nl, and a pair of variables sl,tl containing the start and 
            % end node of the path, respectively.
            node = infeasiblenodes(i);
            first = 0; last = 0; sl = 0; tl = 0;
            for i = 1:size(com,1)
                first = last+1;
                slask = find(nl(last+1:length(nl)) == com(i,1));
                last = slask(1)+first-1;
                if sum(nl(first:last) == node) > 0
                    tl = nl(first);
                    sl = nl(last);
                    break
                end
            end
            % Since we found out path (we always will), we remove it
            % from nl as well as removing its corresponding row in com.
            % If we can replace it, we will.
            nl(first:last) = [];
            com(find(ismember(com, [sl tl], 'rows') == 1), :) = [];
            % Having removed our path from nl, we modify pi by setting an
            % infinite cost for all nodes in nl. This means that when finding
            % an alternative to the path we've removed, the cost of creating
            % a path that isn't vertex-disjoint to the others will be infinite
            % and we can discard such solutions easily.
            pi(nl) = Inf;
            % Using this new pi, we find a new cheapest path between the nodes
            % we removed earlier.
            newnl = gsp(dimX, dimY, pi(:), 1, [tl sl]);
            % If we didn't find a new path, we try again with the next node
            % in the list of infeasible nodes (the modified variables will be
            % reset at the beginning of the next iteration). If we did find
            % a new path, we break out of the loop.
            if length(newnl) < 2 || sum(pi(newnl)) == Inf % If a path wasn't found 
                continue                                  % Continue to next iteration
            else                                          % Else
                break                                     % Break out of the loop
            end
        end
        % Since we're outside the infeasible-node loop, we must have either found a
        % new path, in which case we append it to com/nl, or we didn't, in which case
        % it has been removed from com/nl and we simply update the output variables
        % to match the new set of paths.
        if length(newnl) >= 2 && sum(pi(newnl)) ~= Inf % If a new path was found
            % Append the found path to com/nl
            ncom = [com; sl tl];
            nnl = [nl; flipud(newnl)];
        else
            % Copy the paths without appending anything
            ncom = com;
            nnl = nl;
        end
        % Before the end of the loop, we recalculate the node usage in the same way
        % as before the loop, and update the infeasiblenodes vector to contain the
        % new set of infeasible nodes (which will always be smaller).
        for i=1:length(nodeusage)
            nodeusage(i) = length(find(nl == i));
        end
        infeasiblenodes = find(nodeusage >= 2);
    end
end

