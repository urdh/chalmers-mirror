% TMA521 - Large scale optimization
% Spring 2013
% Project 1, tasks 1 & 2
% Simon Sigurdhsson

% This file is the main file that solves (after editing according to
% instructions in comments) tasks 1 and 2 of the project.

% Files have been organized such that given code (gsp.c, sph.c and
% visagrid.m) resides in a subfolder "given", and the instance files
% are in the "instances" subfolder. Hence, we need to add these to
% the PATH in order to use these files.
% Additionally, all variables are cleared and all figures closed at
% the start of the program, to avoid confusion from earlier results.
addpath('given','instances')
clear all; close all; clc;

% Initialization of variables
% This is where all non-local variables of the program are defined.
% First, we have a couple of variables that control the program flow,
% deciding what instance we are solving and how many iterations we
% should run the subgradient solver for.
p11;             % Problem to solve.
maxIter = 1000;  % Maximum number of subgradient iterations.
% Then, we initialize some of the variables used in the subgradient
% algorithm, so that we don't have to reallocate them inside the
% loop (this is very inefficient). All these variables are set to
% 0 initially, which makes for a good starting value for pi and will
% be overwritten for all other variables, except for the list of
% upper bounds, which is set to Inf (so that all calculated upper
% bounds are smaller), and lambda which is set to 2 in accordance
% with the project description.
pi = zeros(maxIter, dimX*dimY*2); % Lagrangian multipliers for each time step
d = zeros(maxIter, dimX*dimY*2);  % Subgradient direction for each time step
s = zeros(maxIter, 1);            % Step length for each time step
UBDS = ones(maxIter, 1)*Inf;      % Upper bound for each time step
LBDS = zeros(size(UBDS));         % Lower bound for each time step
lambda = 2;                       % Step length modifier
optCom = [];                      % Storage for best feasible solution (com)
optNl = [];                       % Storage for best feasible solution (nl)
optPi = [];                       % Storage for best feasible solution (pi)

% The subgradient scheme (solver)
% This is where the actual work begins. The only stopping criterion
% used is the maximum number of iterations, and the code inside the
% loop pretty much follows the flow chart given in the project
% description.
for t=1:maxIter
    % 1. Solve the Lagrangian subproblems
    % The Lagrangian subproblems are solved as cheapest-path problems
    % by the given function gsp. Since the output of gsp is hard to
    % handle, a function getxij (see getxij.m) is used to transform
    % the output to two 3-dimensional matrices describing the problem
    % variables x_{ijl} and x_{t_{l}s_{l}l}. But first, the okcom
    % function (see okcom.m) eliminates the paths with cost larger
    % than 1, as described in the project description.
    nl = gsp(dimX,dimY,pi(t,:)',k,com);           % Solve the subproblems
    [ok, oknl] = okcom(pi(t,:),k,com,nl);         % Which paths are "ok"?
    kok = find(ismember(com, ok, 'rows') == 1);   % Which rows of com are "ok"?
    [xij, xtlsl] = getxij(dimX,dimY,k,com,nl,kok);% Transform to x_{ijl} matrix

    % 1.1. Calculate the primal feasibility heuristic (only for task 2)
    % The heuristic, described in heuristic.m, creates a feasible
    % solution based on the current solution. It returns data of the
    % same structure as gsp, so it too requires getxij to transform
    % the output into similar matrices.
    [hcom, hnl] = heuristic(dimX, dimY, pi(t,:), k, com, nl);       % Find primal feasible solution
    [hxij, hxtlsl] = getxij(dimX,dimY,k,hcom,hnl,(1:length(hcom))');% Transform to x_{ijl} matrix
    
    % 2. Calculate upper bound, h(pi)
    % The upper bound, essentially the Lagrangian dual value, is
    % calculated as described in the project description. Since the
    % output of gsp has been transformed into a matrix, the actual
    % calculation is very similar to the mathematical formula shown
    % in the project description.
    lpi = repmat(pi(t,:)', [1 dimX*dimY*2 k]);                  % Expand pi, for element-wise multiplication in h-calculation
    h = sum(pi(t,:)) + sum(xtlsl - sum(sum(lpi.*xij, 1), 2), 3);% Calculate h(pi) according to project description
    
    % 2.1. Calculate the lower bound (only for task 2)
    % The lower bound is given by the primal feasible solution found
    % by the heuristic. Since it is a *primal* feasible solution, the
    % lower bound isn't calculated using the Lagrangian dual value but
    % using the original problem formulation. Thus, it is a bit simpler
    % than the calculation of h(pi), but still analogous to the math
    % described in the project description.
    LBDS(t) = sum(hxtlsl, 3); % Count the number of connections made by the primal feasible solution
    % Note that since LBDS(t) = 0 for all t before this assignment is
    % made, simply commenting the above line (along with the code
    % under 1.1) will essentialy solve task 1 instead of task 2.

    % 3. Calculate subgradient direction d
    % Again, since the output of gsp has been transformed into a
    % suitable matrix, the calculation of the subgradient direction is
    % very similar to the mathematical formula given by the project
    % description.
    sxjl = sum(sum(xij,1),3);      % Pre-calculate sum (for efficiency)
    d(t,:) = ones(size(sxjl))-sxjl;% Calculate subgradient direction

    % 4. Calculate step length s
    % The step length calculation is also pretty much a verbatim
    % translation of the mathematical formula into MATLAB code.
    % Note that in task 2 we actually use the lower bound given by
    % the heuristic in the formula, while LBDS=0 for task 1 as
    % suggested by the project description.
    s(t) = lambda*(h-LBDS(t))/sum(d(t,:).^2);% Calculate step length

    % 5. Take step s in direction -d
    % If this isn't the last iteration, the Lagrangian multipliers
    % have to be updated for the next iteration by taking a step in
    % the subgradient direction. Again (there's a pattern here, no?),
    % the transformation of the gsp output makes this a verbatim
    % translation of math into MATLAB code.
    if t ~= maxIter                                               % If this isn't the last iteration
       pi(t+1,:) = max(zeros(size(pi(t,:))),pi(t,:)-s(t).*d(t,:));% Take a step in the subgradient direction
    end

    % 6. Decrease value of lambda
    % In accordance with the project description, lambda is decreased
    % by 5% every iteration. This ensures 0<lambda<2.
    lambda = lambda*0.95;

    % 7. Save for plotting
    % In order to present graphs showing the convergence of the
    % subgradient algorithm along with the best solution found by
    % the heuristic (for task 2), the data is saved in the
    % preallocated variables.
    if (LBDS(t) >= max(LBDS)) % && false % Uncomment "&& false" for task 1
        optCom = hcom(any(hcom,2),:);    % Save the best feasible "com"
        optNl = hnl;                     % Save the best feasible "nl"
        optPi = pi;                      % Save the best feasible "pi"
    end
    UBDS(t) = h;                         % Save the upper bound of the current iteration
    
    % 8. Progress bar (sort of)
    % This simply prints some text every 25th iteration, to roughly
    % indicate how far the algorithm has come and how long we have
    % to wait before it will terminate.
    if mod(t,25) == 0
       disp(['Iteration ', num2str(t), ' of ', num2str(maxIter)])
    end
end

% Plotting results
% The subgradient algorithm is done, and it is time to show the
% results. First, a plot showing the convergence of the subgradient
% algorithm and the heuristic (in task 2) is shown. Since all data
% has been saved, this is fairly standard and boring MATLAB code.
plot(1:maxIter, UBDS, 'k-'); hold on;       % Plot the upper bounds
plot(1:maxIter, k*ones(size(UBDS)), 'k--'); % Indicate the number of connections we want
plot(1:maxIter, LBDS, 'k:');                % Plot the lower bounds (only useful in task 2)
axis([1 maxIter 0 max(k, max(UBDS))+2]);    % Set sensible axes
xlabel('Iterations');                       % Label the x axis
ylabel('Connections');                      % Label the y axis
legend('Dual objective value','Connections required','Primal feasible solution'); % Explain plots
% Next (only for task 2, comment out if running task 1), the best
% primal feasible solution found by the heuristic is shown using
% the given visagrid function. Again, nothing strange happening.
figure;                                     % Get a new figure
visagrid(dimX,dimY,optNl,optCom,optPi,25);  % Show the feasible solution
