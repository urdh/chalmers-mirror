public interface MyIntSet 
{   
       public boolean member(int element);
}
  
