import java.io.*;
import java.util.Scanner;

public class Lab1A 
{
   public static void main(String[] args) 
     {
        if(args.length != 2) 
	  {
	     // Not enough arguments!
	     System.out.println("Usage: Lab1A <element> <file>");
	  }
	else
	  {
	     try
	       {
		  int element = Integer.parseInt(args[0]);
		  MySortedIntArray array = new MySortedIntArray();
		  // Read ints into array
		  Scanner file = new Scanner(new File(args[1]));
		  while(file.hasNextInt())
		    array.add(file.nextInt());
		  // Find element and print result
		  System.out.println(array.member(element));
	       }
	     catch(FileNotFoundException e)
	       {
		  System.out.println("File not found!");
	       }
	     
	  }
	
     }
   
}
