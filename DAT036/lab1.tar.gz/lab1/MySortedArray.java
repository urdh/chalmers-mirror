import java.util.*;

public class MySortedArray<E> implements MySet<E> 
{
   private Object[] set;
   private int elements;
   private Comparator<E> c;
   
   public MySortedArray() 
     {
	elements = 0;
	set = new Object[5];
	c = new MyDefaultComparator<E>();
     }
   
   public MySortedArray(Comparator<E> comp) 
     {
	this();
	c = comp;
     }
   
   // add an element to the set
   // 
   // if the array is full, double its length
   // (or rather, create a new one double the length and
   //  copy the old elements to this new array)
   public void add(E element) 
     {
	elements++;
	if(elements >= set.length) 
	  {
	     Object[] temp = set;
	     set = new Object[2 * set.length];
	     for(int i=0; i<elements; i++) set[i] = temp[i];
	  }
	set[elements-1] = element;
     }
   
   public boolean member(E element) 
     {
	return BinarySearch(element, 0, elements-1);
     }
   
   // perform a recursive binary search
   // returns true if element is in set, false otherwise
   private boolean BinarySearch(E k, int low, int high) 
     {
	if(low>high) return false;
	else 
	  {
	     int mid = (low+high)/2;
	     E e = (E)set[mid];
	     if(c.compare(k,e) == 0) return true;
	     else if(c.compare(k,e) < 0) return BinarySearch(k, low, mid-1);
	     else return BinarySearch(k, mid+1, high);
	  }
     }
   
   // a default comparator; compares objects by their toString() value
   private class MyDefaultComparator<E> implements Comparator<E> 
     {
        public int compare(E a, E b) 
	  {
	     return a.toString().compareTo(b.toString());
	  }
	
	public boolean equals(Object o) 
	  {
	     return o == this;
	  }
     }
   
}
