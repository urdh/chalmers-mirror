public interface MySet<E> 
{   
       public boolean member(E element);
}
  
