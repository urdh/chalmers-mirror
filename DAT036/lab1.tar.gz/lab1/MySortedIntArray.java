
public class MySortedIntArray implements MyIntSet 
{
   private int[] set;
   private int elements;
   
   public MySortedIntArray() 
     {
	elements = 0;
	set = new int[5];
     }
   
   // add an element to the set
   //
   // if the array is full, double its length
   // (or rather, create a new one double the length and
   //  copy the old elements to this new array)
   public void add(int element) 
     {
	elements++;
	if(elements >= set.length) 
	  {
	     int[] temp = set;
	     set = new int[2 * set.length];
	     for(int i=0; i<elements; i++) set[i] = temp[i];
	  }
	set[elements-1] = element;
     }
   
   public boolean member(int element) 
     {
	return BinarySearch(element, 0, elements-1);
     }
   
   // perform a recursive binary search
   // returns true if element is in set, false otherwise
   private boolean BinarySearch(int k, int low, int high) 
     {
	if(low>high) return false;
	else 
	  {
	     int mid = (low+high)/2;
	     int e = set[mid];
	     if(k == e) return true;
	     else if(k < e) return BinarySearch(k, low, mid-1);
	     else return BinarySearch(k, mid+1, high);
	  }
     }
   
   
}
