import java.io.*;
import java.util.*;

public class Lab1B 
{
   public static void main(String[] args) 
     {
        if(args.length != 2) 
	  {
	     // Not enough arguments!
	     System.out.println("Usage: Lab1B <element> <file>");
	  }
	else
	  {
	     try
	       {
		  int element = Integer.parseInt(args[0]);
		  MySortedArray<Integer> array = new MySortedArray<Integer>(new MyIntComparator());
		  // Read ints into array
		  Scanner file = new Scanner(new File(args[1]));
		  while(file.hasNextInt())
		    array.add(file.nextInt());
		  // Find element and print result
		  System.out.println(array.member(element));
	       }
	     catch(FileNotFoundException e)
	       {
		  System.out.println("File not found!");
	       }
	     
	  }
	
     }
   
   // integer comparator, uses Integer.compareTo()
   private static class MyIntComparator implements Comparator<Integer> 
     {
	public int compare(Integer a, Integer b)
	  {
	     return a.compareTo(b);
	  }
	
	public boolean equals(Object o)
	  {
	     return o == this;
	  }
	
     }
   
}
