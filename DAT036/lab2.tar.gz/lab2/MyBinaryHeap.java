import java.util.*;

/**
 * Binary heap based on array.
 *
 * @param <E> Type of elements in heap
 */
public class MyBinaryHeap<E> {

	private Comparator<Integer> c;
	private Vector<PriorityPair> v;
	private HashMap<E, Integer> h;
	
	/**
	 * Create a new binary min-heap with respect to
	 * the default integer comparator
	 */
	public MyBinaryHeap() {
		this(new DefaultIntComparator());
	}
	
	/**
	 * Create a new binary min-heap with respect to
	 * the comparator <tt>c</tt>
	 * 
	 * @param c Comparator used in heap
	 */
	public MyBinaryHeap(Comparator<Integer> c) {
		this.c = c;
		this.v = new Vector<PriorityPair>();
		this.h = new HashMap<E, Integer>();
	}
	
	/**
	 * Add an element to the heap
	 * 
	 * @param priority Value of element in heap
	 * @param data Data stored at value <tt>priority</tt>
	 */
	public void add(Integer priority, E data) {
		v.add(new PriorityPair(priority, data));
		h.put(data, v.size()-1);
		bubbleup(v.size()-1);
	}
	
	private int parentOf(int i) {
		return i/2;
	}
	
	private int firstChild(int i) {
		return 2*i;
	}
	
	private int secondChild(int i) {
		return 2*i + 1;
	}
	
	private void bubbleup(int i) {
		if(c.compare(v.get(parentOf(i)).priority, v.get(i).priority) > 0) {
			swap(i, parentOf(i));
			bubbleup(parentOf(i));
		}
	}
	
	private void bubbledown(int i) {
		if(secondChild(i) < v.size() && c.compare(v.get(secondChild(i)).priority, v.get(firstChild(i)).priority) < 0) {
			if(c.compare(v.get(secondChild(i)).priority, v.get(i).priority) < 0) {
				swap(i, secondChild(i));
				bubbledown(secondChild(i));
			}
		} else {
			if(firstChild(i) < v.size() && c.compare(v.get(firstChild(i)).priority, v.get(i).priority) < 0) {
				swap(i, firstChild(i));
				bubbledown(firstChild(i));
			}
		}
	}
	
	/**
	 * Remove top element from the heap
	 * 
	 * @return The removed element
	 */
	public E remove() {
		PriorityPair m = v.get(0);
		h.remove(m.data);
		if(v.size() > 1){
			PriorityPair e = v.remove(v.size()-1);
			h.remove(e.data); h.put(e.data, 0);
			v.setElementAt(e, 0);
			bubbledown(0);
		} else {
			v.remove(0);
		}
		return m.data;
	}
	
	/**
	 * Check if and where the element exists in the heap
	 * 
	 * @param data Data of element to find
	 * @return Value at which data is stored, null if data not in heap
	 */
	public Integer find(E data) {
		return h.get(data);
	}
	
	/**
	 * Peek at top element in heap
	 * 
	 * @return Value of top element in heap
	 */
	public E peek() {
		if(empty()) return null;
		return v.get(0).data;
	}
	
	/**
	 * Peek at priority of top element in heap
	 * 
	 * @return Priority of top element in heap
	 */
	public Integer peekPrio() {
		if(empty()) return null;
		return v.get(0).priority;
	}
	
	/**
	 * Peek at priority of an element
	 * 
	 * @param elem Element to peek priority of
	 * @return Priority of element
	 */
	public Integer peekPrio(E elem) {
		if(find(elem) == null) return null;
		return v.get(find(elem)).priority;
	}
	
	/**
	 * Check if the heap is empty
	 * 
	 * @return true if the heap is empty, false otherwise
	 */
	public Boolean empty() {
		return (v.size() == 0);
	}
	
	/**
	 * Update the key of an element in the heap
	 * 
	 * @param data Element to update
	 * @param newprio New priority
	 * @return The updated element, null if update failed
	 */
	public E replaceKey(E data, Integer newprio) {
		if(h.get(data) == null) return null;
		int pos = h.get(data);
		PriorityPair e = v.get(pos);
		e.priority = newprio;
		v.set(pos, e);
		bubbleup(pos);
		bubbledown(pos);
		return data;
	}
	
	private void swap(Integer p1, Integer p2) {
		PriorityPair a = v.get(p1);
		PriorityPair b = v.get(p2);
		v.setElementAt(b, p1);
		v.setElementAt(a, p2);
		h.remove(a.data);
		h.remove(b.data);
		h.put(a.data, p2);
		h.put(b.data, p1);
	}
	
	class PriorityPair {
		public Integer priority;
		public E data;
		PriorityPair(int p, E d) {
			priority = p;
			data = d;
		}
		public String toString() {
			return data+" "+priority;
		}
	}
	
	/**
	 * Comparator for Integers
	 */
	static class DefaultIntComparator implements Comparator<Integer> {
		public int compare(Integer o1, Integer o2) {
			return o1.compareTo(o2);
		}
	}
	
	/**
	 * "Inverse" Comparator for integers
	 */
	static class ReverseIntComparator implements Comparator<Integer> {
		public int compare(Integer o1, Integer o2) {
			return -o1.compareTo(o2);
		}
	}
}
