import java.io.*;
import java.util.*;

public class Aktiehandel {
	private static MyBinaryHeap<String> salj, kop;

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		salj = new MyBinaryHeap<String>();
		kop = new MyBinaryHeap<String>(new MyBinaryHeap.ReverseIntComparator());
		try {
			if(args.length > 0) in = new Scanner(new File(args[0]));
			while(in.hasNext()) {
				String namn = in.next();
				String op = in.next();
				int varde = in.nextInt();
				if(op.equals("K")) {
					kop.add(varde, namn);
				} else if(op.equals("S")) {
					salj.add(varde, namn);
				} else if(op.equals("NS")) {
					int vns = in.nextInt();
					if(salj.find(namn) != null && salj.peekPrio(namn) == varde) {
						salj.replaceKey(namn, vns);
					} else {
						System.err.println("Fel: "+namn+" försöker ändra ett bud som inte finns (S:"+varde+"->"+vns+")!");
					}
				} else if(op.equals("NK")) {
					int vnk = in.nextInt();
					if(kop.find(namn) != null && kop.peekPrio(namn) == varde) {
						kop.replaceKey(namn, vnk);
					} else {
						System.err.println("Fel: "+namn+" försöker ändra ett bud som inte finns (S:"+varde+"->"+vnk+")!");
					}
				}
				while(!kop.empty() && !salj.empty() && kop.peekPrio() >= salj.peekPrio()) {
					System.out.println(kop.peek() + " köper från " + salj.peek() + " för " + kop.peekPrio() + " kr");
					kop.remove();
					salj.remove();
				}
			}
			System.out.println("");
			orderbok();
		} catch (FileNotFoundException e) {
			System.err.println("Fel: Kan inte öppna fil!");
			e.printStackTrace();
		}
	}
	
	public static void orderbok() {
		System.out.println("Orderbok:");
		System.out.print("Säljare: ");
		MyBinaryHeap<String> temp1 = new MyBinaryHeap<String>();
		while(!salj.empty()) {
			System.out.print(salj.peek()+" "+salj.peekPrio()+", ");
			temp1.add(salj.peekPrio(), salj.peek());
			salj.remove();
		}
		salj = temp1;
		System.out.println("");
		System.out.print("Köpare: ");
		MyBinaryHeap<String> temp2 = new MyBinaryHeap<String>(new MyBinaryHeap.ReverseIntComparator());
		while(!kop.empty()) {
			System.out.print(kop.peek()+" "+kop.peekPrio()+", ");
			temp2.add(kop.peekPrio(), kop.peek());
			kop.remove();
		}
		kop = temp2;
		System.out.println("");
	}
}
