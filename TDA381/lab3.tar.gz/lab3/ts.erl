-module(ts).
-export([new/0, in/2, out/2]).
-import(lists).

new() ->
    spawn_link(fun() -> loop(0, [], []) end).

out(PID, T) when is_tuple(T), is_pid(PID) -> PID ! {o, T}, true;
out(_, _) -> false.

in(PID, P) when is_tuple(P), is_pid(PID) ->
    Ref = make_ref(),
    PID ! {i, self(), P, Ref},
    receive
        {ans, Ref, Anything} -> Anything
    end;
in(_, _) -> false.

%% Helpers

loop(Count, List, Pats) when is_list(List), is_list(Pats) ->
    receive
        {o, Anything} -> 
	    {Pid, Ref, Pattern} = matchlist(Anything, Pats),
	    if
	        Pid == false -> L = List ++ [Anything], P = Pats;
		true -> Pid ! {ans, Ref, Anything}, P = Pats -- [{Pid,Ref,Pattern}], L = List
	    end,
            loop(Count + 1, L, P);
        {i, To, Pattern, Ref} ->
            Match = listmatch(Pattern, List),
            if
                Match == [] -> P = Pats ++ [{To, Ref, Pattern}], L = List;
                true -> To ! {ans, Ref, Match}, L = List -- [Match], P = Pats
            end,
            loop(Count + 1, L, P)
    end;
loop(Count, List, Pats) when is_list(Pats) -> loop(Count, [List], Pats);
loop(Count, List, Pats) when is_list(List) -> loop(Count, List, [Pats]);
loop(Count, List, Pats) -> loop(Count, [List], [Pats]).

matchlist(Anything, [H|T]) when is_tuple(Anything) ->
    {_, _, Tuple} = H,
    IsMatch = match(Tuple, Anything),
    if
        IsMatch -> H;
	true -> matchlist(Anything, T)
    end;
matchlist(_, []) -> {false, false, []};
matchlist(_, _) -> {false, false, []}.

listmatch(Pattern, [H|T]) when is_tuple(Pattern) ->
    IsMatch = match(Pattern, H),
    if
        IsMatch -> H;
        true -> listmatch(Pattern, T)
    end;
listmatch(_, []) -> [];
listmatch(_, _) -> [].

%% Match function as given in assignment

match(any,_) -> true;
match(P,Q) when is_tuple(P), is_tuple(Q)
                -> match(tuple_to_list(P),tuple_to_list(Q));
match([P|PS],[L|LS]) -> case match(P,L) of
                              true -> match(PS,LS); 
                              false -> false
                         end;
match(P,P) -> true;
match(_,_) -> false.