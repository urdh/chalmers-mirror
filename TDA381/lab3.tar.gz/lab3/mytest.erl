-module(mytest).
-export([summation/0, factorial/0, both/0]).
-import(ts).

%% Three tests:
%%  summation() performs 100 summations on 10 clients
%%  factorial() performs 100 factorials on 10 clients
%%  both() does both these things at the same time
%%
%% These are simply to demonstrate that the tuple space works for multiple
%% processes and multiple calculations at once. The tuples send and received
%% can be improved (in order to properly associate operation with result), but
%% for the purposes of this test -- textual output -- the information returned
%% by the clients is both suitably formatted and sensible.

summation() ->
    Linda = ts:new(),
    _P1 = spawn_link(fun() -> receiveloop(0, Linda) end),
    _P2 = spawn_link(fun() -> spawnproc(fun() -> sumproc(0, Linda) end, Linda, 10) end),
    sumloop(Linda, 100).

factorial() ->
    Linda = ts:new(),
    _P1 = spawn_link(fun() -> receiveloop(0, Linda) end),
    _P2 = spawn_link(fun() -> spawnproc(fun() -> factproc(0, Linda) end, Linda, 10) end),
    factloop(Linda, 100).
    
both() ->
    Linda = ts:new(),
    _P1 = spawn_link(fun() -> receiveloop(0, Linda) end),
    _P2 = spawn_link(fun() -> spawnproc(fun() -> sumproc(0, Linda) end, Linda, 10) end),
    _P3 = spawn_link(fun() -> spawnproc(fun() -> factproc(0, Linda) end, Linda, 10) end),
    _P4 = spawn_link(fun() -> sumloop(Linda, 100) end),
    _P5 = spawn_link(fun() -> factloop(Linda, 100) end).
    
%% Helpers

spawnproc(_F, _Pid, 0) -> ok;
spawnproc(F, Pid, Num) ->
    _Proc = spawn_link(F()),
    spawnproc(F, Pid, Num - 1).

receiveloop(Count, Pid) ->
    {_, Op, Ans} = ts:in(Pid, {ans, any, any}),
    io:format("Received answer: ~s = ~w~n", [Op, Ans]),
    receiveloop(Count+1, Pid).
    
sumproc(Count, Pid) ->
    {_, A, B} = ts:in(Pid, {sum, any, any}),
    ts:out(Pid, {ans, io_lib:format("~w+~w", [A, B]), A + B}),
    sumproc(Count+1, Pid).

factproc(Count, Pid) ->
    {_, A} = ts:in(Pid, {fact, any}),
    ts:out(Pid, {ans, io_lib:format("~w!", [A]), fact(A)}),
    factproc(Count, Pid).

sumloop(_Pid, 0) -> ok;
sumloop(Pid, Count) ->
    ts:out(Pid, {sum, random:uniform(20), random:uniform(20)}),
    sumloop(Pid, Count - 1).

factloop(_Pid, 0) -> ok;
factloop(Pid, Count) ->
    ts:out(Pid, {fact, random:uniform(30)}),
    factloop(Pid, Count - 1).

% Naive (non-tail) recursion
fact(0) -> 1;
fact(N) -> N * fact(N - 1).
