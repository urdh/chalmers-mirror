x=[0:.05:12];
g=9.82;
vnoll=10;
ynoll=1.8;

for theta=15:15:75
    y=(ynoll-(g/(2*vnoll^2*cosd(theta)^2))*(x-(vnoll^2*sind(2*theta))/(2*g)).^2+(vnoll^2*sind(theta)^2)/(2*g))
    plot(x,y);
    hold on
end
axis([0 12 -1 7])
xlabel('x')
ylabel('y(x)')
title('Kastbana med v_0=10, y_0=1.8 och olika \theta')
text(0.75,4.15,'75^o')
text(1.25,3.95,'60^o')
text(1.75,3.50,'45^o')
text(2.25,3.00,'30^o')
text(2.40,2.50,'15^o')
plot(x, (y./y-1), 'green')
grid on
hold off
print -r300 -depsc Figur