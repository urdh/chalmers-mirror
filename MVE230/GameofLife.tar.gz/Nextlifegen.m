function b=Nextlifegen(lgrid)
    [w h]=size(lgrid);
    l=zeros(w+2,h+2);
    l(2:(w+1),2:(h+1))=lgrid;
    old=lgrid;
    lgrid=l;
    ng = zeros(w,h);
    for i=0:2
        for j=0:2
            ng = ng + lgrid((i+1):(w+i), (j+1):(h+j));
        end
    end
    nng = not(ng.*old-4)+not(ng.*old-3);
    nng = nng + not(ng.*not(old)-3);
    b = nng;
end