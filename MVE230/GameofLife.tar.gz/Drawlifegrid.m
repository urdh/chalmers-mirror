function a = Drawlifegrid(lgrid)
    clf;
    [w h] = size(lgrid);
    axis([0 w 0 h]);
    axis image;
    [i j] = find(lgrid); i=i'; j=j';
    patch([i-1;i;i;i-1],[j-1;j-1;j;j],[i+j-2;i+j-1;i+j;i+j-1],'EdgeColor','none');
end