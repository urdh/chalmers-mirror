drawlife = @Drawlifegrid;
nextgen = @Nextlifegen;
clf;
colormap('summer');

% Inmatning
MODE = 'rand'; % 'rand', 'man', 'resume' eller ett filnamn

width=1000;
height=625;

axis([0 width 0 height]);
axis image;

hlinex = [0:1:width;0:1:width];
hliney = [zeros(1,width+1);height*ones(1,width+1)];
vlinex = [zeros(1,height+1);width*ones(1,height+1)];
vliney = [0:1:height;0:1:height];
 linec = [.7 .7 .7];

line(hlinex, hliney, 'Color', linec)
line(vlinex, vliney, 'Color', linec)

switch MODE
    case 'man'
        life=zeros(width,height);
        text(width/2, 0, '\bfV�lj punkter genom att klicka, och tryck ENTER efter sista punkten.', 'Color', 'b', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
        [x y] = ginput(1);
        life(floor(x)+1,floor(y)+1) = not(life(floor(x)+1,floor(y)+1));
        drawlife(life);
        while(1)
            line(hlinex, hliney, 'Color', linec)
            line(vlinex, vliney, 'Color', linec)
            [x y] = ginput(1);
            if(x > 0 && x < width && y > 0 && y < height)
                if(isempty(x) ~= 1)
                    life(floor(x)+1,floor(y)+1) = not(life(floor(x)+1,floor(y)+1));
                    drawlife(life);
                else
                    %saveas(gcf,'Figur1.eps');
                    drawlife(life);
                    break
                end
            end
        end
    case 'rand'
        life=zeros(width,height);
        life = round(rand(size(life)));
    case 'resume'
        % Do nothing.
    otherwise
        life=zeros(width,height);
        load(MODE);
        [w h] = size(v);
        x = ceil((width/2)-(w/2));
        y = ceil((height/2)-(h/2));
        life(x:(x+w-1),y:(y+h-1)) = v;
end

if(strcmp(MODE,'resume')==0)
    generations = 0;
end
tic;
while(1)
    before = sum(sum(life));
    life=nextgen(life);
    drawlife(life);
    toc;
    t=toc;
    tic;
    text(width/200, height, ['\bfGeneration ', num2str(generations)], 'Color', 'b', 'VerticalAlignment', 'top');
    text(width/200, height, ['\bfLevande celler: ', num2str(sum(sum(life)))], 'Color', 'b', 'VerticalAlignment', 'baseline');
    text(width-width/200, height, ['\bfGenerationer per sekund: ', num2str(1/t)], 'Color', 'b', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'right');
    text(width-width/200, height, ['\bfCeller per generation: ', num2str(sum(sum(life))-before)], 'Color', 'b', 'VerticalAlignment', 'baseline', 'HorizontalAlignment', 'right');
    pause(0.01);
    generations = generations + 1;
end