function a = Drawlifegrid(lgrid)
    cla;
    [w h] = size(lgrid);
    for i=1:w
        for j=1:h
            if lgrid(i,j)==1
                patch([i-1;i;i;i-1],[j-1;j-1;j;j],[0 .8 0],'EdgeColor', 'none');
            end
        end
    end
end