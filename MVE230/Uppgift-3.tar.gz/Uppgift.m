drawlife = @Drawlifegrid;
nextgen = @Nextlifegen;

width=150;
height=113;

life=zeros(width,height);
axis([0 width 0 height]);
axis image;
cla;

hlinex = [0:1:width;0:1:width];
hliney = [zeros(1,width+1);height*ones(1,width+1)];
vlinex = [zeros(1,height+1);width*ones(1,height+1)];
vliney = [0:1:height;0:1:height];
 linec = [.7 .7 .7];

line(hlinex, hliney, 'Color', linec)
line(vlinex, vliney, 'Color', linec)

text(width/2, 0, '\bfV�lj punkter genom att klicka, och tryck ENTER efter sista punkten.', 'Color', 'b', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
[x y] = ginput(1);
life(floor(x)+1,floor(y)+1) = not(life(floor(x)+1,floor(y)+1));
drawlife(life);
while(1)
    line(hlinex, hliney, 'Color', linec)
    line(vlinex, vliney, 'Color', linec)
    [x y] = ginput(1);
    if(isempty(x) ~= 1)
        life(floor(x)+1,floor(y)+1) = not(life(floor(x)+1,floor(y)+1));
        drawlife(life);
    else
        %saveas(gcf,'Figur1.eps');
        drawlife(life);
        break
    end
end

generations = 0;
while(1)
    life=nextgen(life);
    drawlife(life);
    text(width/200, height, ['\bfGeneration ', num2str(generations)], 'Color', 'b', 'VerticalAlignment', 'top');
    pause(25/(width*height));
    generations = generations + 1;
end