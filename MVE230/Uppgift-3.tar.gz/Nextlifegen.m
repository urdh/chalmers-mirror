function b=Nextlifegen(lgrid)
    [w h]=size(lgrid);
    l=zeros(w+2,h+2);
    l(2:(w+1),2:(h+1))=lgrid;
    lgrid=l;
    ng=zeros(w,h);
    for i=2:(w+1)
        for j=2:(h+1)
            previ=i-1;
            nexti=i+1;
            prevj=j-1;
            nextj=j+1;
            gr = lgrid(previ:nexti,prevj:nextj);
            gr(2,2)=0;
            s=sum(sum(gr));
            if lgrid(i,j)==1 && (s==2 || s==3)
                ng(previ,prevj)=1;
            elseif lgrid(i,j)==0 && s==3 
                ng(previ,prevj)=1;
            else
                ng(previ,prevj)=0;
            end
        end
    end
    b=ng;
end