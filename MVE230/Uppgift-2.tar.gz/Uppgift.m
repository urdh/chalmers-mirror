lngd = @Langd;
area = @Area;

axis([0 1 0 1]);
grid on;
hold on;
axis square;
set(gca,'ytick',[0 0.2 0.4 0.6 0.8 1]);
set(gca,'xtick',[0 0.2 0.4 0.6 0.8 1]);

X = [0];
Y = [0];

text(0.02, 0.96, '\bfV�lj punkter genom att klicka, och tryck ENTER efter sista punkten.', 'Color', 'b')
[X(1) Y(1)] = ginput(1);
plot(X(1), Y(1), 'bo-');
while(1)
    [x y] = ginput(1);
    if(isempty(x) ~= 1)
        X(:, end+1) = x;
        Y(:, end+1) = y;
        plot(X, Y, 'bo-');
    else
        saveas(gcf,'Figur1.eps')
        X(:, end+1) = X(1);
        Y(:, end+1) = Y(1);
        plot(X, Y, 'bo-');
        break
    end
end

cla;
plot(X, Y, 'b-');
fill(X, Y, 'g');

text(0.02, 0.02, ['\bfL�ngden �r: ', num2str(lngd(X, Y, 1)), ' le'], 'Color', 'b')
text(0.98, 0.02, ['\bfArean �r: ', num2str(area(X, Y, 0)), ' ae'], 'HorizontalAlignment', 'right', 'Color', 'b')
hold off
saveas(gcf,'Figur2.eps')
