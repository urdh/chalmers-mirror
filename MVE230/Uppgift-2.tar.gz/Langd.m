function a = Langd(X, Y, n) 
    b = @Langd;
    if(n+1 > length(X))
        a = 0;
    else
        a = sqrt((X(:,n+1)-X(:,n))^2 + (Y(:,n+1)-Y(:,n))^2) + b(X, Y, n+1);
end