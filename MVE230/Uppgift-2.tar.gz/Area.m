function a = Area(X, Y, n) 
    b = @Area;
    if(n == 0)
        a = abs(b(X, Y, n+1)/2);
    elseif(n+1 > length(X))
        a = 0;
    else
        a = ((X(:,n+1)+X(:,n))*(Y(:,n+1)-Y(:,n))) + b(X, Y, n+1);
end