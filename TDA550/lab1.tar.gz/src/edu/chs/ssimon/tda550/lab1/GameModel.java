package edu.chs.ssimon.tda550.lab1;

import java.awt.*;

/**
 * Common superclass for all game model classes.
 *
 * When implementing a this interface you should:
 *
 * <ul>
 * <li>Implement the doCommand() method</li>
 * <li>Initiate the elements of the ga
 * A particular game model must implement doCommand.
 *
 * Constructors of subclasses should initiate matrix elements
 * and additional, game-dependent fields.
 */
public abstract class GameModel {

	/** A Matrix containing the state of the gameboard. */
	private GameTile[][] gameboardState;

	/** The size of the state matrix. */
	private Dimension gameboardSize = GameFactory.getGameSize();


	/**
	 * Create a new game model.
	 * As GameModel is an abstract class, this is only
	 * intended for subclasses.
	 */
	protected GameModel() {
		gameboardState = 
			new GameTile[gameboardSize.width][gameboardSize.height];
	}


        /**
	 * Set the tile on a specified position in the gameboard.
	 *
	 * @param pos The position in the gameboard matrix.
	 * @param tile The type of tile to paint in specified position
	 */
	protected void setGameboardState(Position pos, GameTile tile) {
		setGameboardState(pos.x, pos.y, tile);
	}

        /**
	 * Set the tile on a specified position in the gameboard.
	 *
	 * @param x Coordinate in the gameboard matrix.
	 * @param y Coordinate in the gameboard matrix.
	 * @param tile The type of tile to paint in specified position
	 */
	protected void setGameboardState(int x, int y, GameTile tile) {
		gameboardState[x][y] = tile;
	}


        /**
	 * Returns the GameTile in logical position (x,y)
	 * of the gameboard. 
	 *
	 * @param pos The position in the gameboard matrix.
	 */
	public GameTile getGameboardState(Position pos) {
		return getGameboardState(pos.x, pos.y);
	}
		
        /**
	 * Returns the GameTile in logical position (x,y)
	 * of the gameboard. 
	 *
	 * @param x Coordinate in the gameboard matrix.
	 * @param y Coordinate in the gameboard matrix.
	 */
	public GameTile getGameboardState(int x, int y) {
		return gameboardState[x][y];
	}
    
	/**
	 * Returns the size of the gameboard.
	 */
	public Dimension getGameboardSize() {
		return gameboardSize;
	}

        /**
	 * This method is called repeatedly so that the
	 * game can update it's state.
	 *
	 * @param lastKey The most recent keystroke.
	 */
	public abstract void gameUpdate(int lastKey) throws GameOverException;
}
