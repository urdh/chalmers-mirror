package edu.chs.ssimon.tda550.lab1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

/**
 * A pretty little floor tile
 * 
 * @author Simon Sigurdhsson
 *
 */
public class FloorTile extends GameTile {
	/** The colors of this tile */
	private Color c, e, l;
	
	/**
	 * Create a new floor tile
	 * 
	 * @param center the color in the center of the tile
	 * @param dedge the color on the dark edge of the tile
	 * @param ledge the color on the light edge of the tile
	 */
	public FloorTile(Color center, Color dedge, Color ledge) {
		this.c = center;
		this.e = dedge;
		this.l = ledge;
	}
	
	/**
	 * @return the c
	 */
	public Color getC() {
		return c;
	}

	/**
	 * @return the e
	 */
	public Color getE() {
		return e;
	}

	/**
	 * @return the l
	 */
	public Color getL() {
		return l;
	}

	/**
     * Draws itself in a given graphics context, position and size.
     *
     * @param g graphics context to draw on.
     * @param x pixel x coordinate of the tile to be drawn.
     * @param y pixel y coordinate of the tile to be drawn.
     * @param d size of this object in pixels.
     */
    public void draw(Graphics g, int x, int y, Dimension d) {
    	g.setColor(c);
    	g.fillRect(x,y,d.width,d.height);
    	g.setColor(l);
    	g.drawLine(x, y, x+d.width-1, y);
    	g.drawLine(x, y, x, y+d.height-1);
    	g.setColor(e);
    	g.drawLine(x+d.width-1, y, x+d.width-1, y+d.height-1);
    	g.drawLine(x, y+d.height-1, x+d.width-1, y+d.height-1);
    }
}
