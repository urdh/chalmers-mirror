package edu.chs.ssimon.tda550.lab1;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Simple Snake game based on the given game package.
 * 
 * @author Simon Sigurdhsson
 *
 */
public class SnakeModel extends GameModel {

	private static final int NORTH = 0;
	private static final int WEST = 1;
	private static final int SOUTH = 2;
	private static final int EAST = 3;
	
	/** Graphical representation of an empty tile */
	private FloorTile noTile = new FloorTile(Color.gray, Color.darkGray, Color.lightGray);
	/** Graphical representation of a snake segment */
	private GameTile snakeTile = new SnakeTile(noTile, Color.green);
	/** Graphical representation of an apple */
	private GameTile appleTile = new AppleTile(noTile, Color.red.darker());
	
	/** Position of the current apple */
	private Position theApple = null;
	/** Position of all snake segments, with the last one being the head */
	private java.util.Vector<Position> theSnake = new Vector<Position>();
	
	/** Direction of travel */
	private int direction = NORTH;
	/** Current score */
	private int score = 0;
	
	/** Random number generator */
	private Random r = new Random();
	
	/**
	 * Create a model for the Snake game
	 */
	public SnakeModel() {
		Dimension size = getGameboardSize();
		// Start with a clean board
		for (int i=0; i<size.width; i++) {
			for (int j=0; j<size.height; j++) {
				setGameboardState(i, j, this.noTile);
			}
		}
		// We need a snake as well.
		for (int dy=1; dy>-2; dy--) {
			Position piece = new Position(size.width/2, size.height/2 + dy);
			theSnake.add(piece);
			setGameboardState(piece, this.snakeTile);
		}
		// ...and an apple.
		this.newApple();
	}
	
	/**
	 * Create a new apple and add it to the board.
	 */
	private void newApple() {
		Dimension size = getGameboardSize();
		Position newPos;
		do {
			newPos = new Position(r.nextInt(size.width), r.nextInt(size.height));
		} while(isSnake(newPos));
		theApple = newPos;
		setGameboardState(theApple, this.appleTile);
	}

	/**
	 * Check if the tile has a snake segment
	 * 
	 * @param pos Position to check
	 * @return true if tile has a snake segment
	 */
	private Boolean isSnake(Position pos) {
		return (getGameboardState(pos) == this.snakeTile);
	}
	
	/**
	 * Check if the tile has an apple
	 * 
	 * @param pos Position to check
	 * @return true if tile has an apple
	 */
	private Boolean isApple(Position pos) {
		return (getGameboardState(pos) == this.appleTile);
	}
	
	/**
	 * Update the direction of the collector
	 * according to the users keypress.
	 */
	private void updateDirection(int key) {
		switch (key) {
		case KeyEvent.VK_LEFT:  
			direction = WEST;  
			break;
		case KeyEvent.VK_UP:  
			direction = NORTH;
			break;
		case KeyEvent.VK_RIGHT:
			direction = EAST;
			break;
		case KeyEvent.VK_DOWN:
			direction = SOUTH;
			break;
		default:
			// Don't change direction if another key is pressed
			break;
		}
	}
	
	/**
	 * This method is called repeatedly so that the
	 * game can update its state.
	 *
	 * @param lastKey The most recent keystroke.
	 */
	public void gameUpdate(int lastKey) throws GameOverException {
		try {
			updateDirection(lastKey);
			
			// Remove last snake piece
			Position newHead = theSnake.remove(0);
			if(theSnake.get(0) != newHead) setGameboardState(newHead, noTile);
			// Find position of new snake head
			Position oldHead = theSnake.lastElement();
			switch(direction) {
			case NORTH:
				newHead = new Position(oldHead.x, oldHead.y-1);
				break;
			case WEST:
				newHead = new Position(oldHead.x-1, oldHead.y);
				break;
			case SOUTH:
				newHead = new Position(oldHead.x, oldHead.y+1);
				break;
			case EAST:
				newHead = new Position(oldHead.x+1, oldHead.y);
				break;
			default:
				throw new RuntimeException();
			}
			// Check if the snake is eating itself
			if(isSnake(newHead)) {
				throw new GameOverException(score);
			}
			// Check if an apple is being eaten
			if(isApple(newHead)) {
				score++;
				setGameboardState(theApple, noTile);
				theSnake.add(0, theSnake.get(0));
				newApple();
			}
			// Add new snake head
			theSnake.add(newHead);
			setGameboardState(newHead, snakeTile);
		} catch(ArrayIndexOutOfBoundsException e) {
			// Snake is moving outside the board -- GAME OVER.
			throw new GameOverException(score);
		}
	}

}
