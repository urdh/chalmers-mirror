package edu.chs.ssimon.tda550.lab1;


import java.awt.*;
import java.awt.event.*;

/**
 * This panel is meant to be the base of a window or applet. It will add a new
 * GameView with a corresponding GameController to itself. It will also provide
 * a gui for choosing a new game. The list of games will be aquired from
 * GameFactory.
 */
@SuppressWarnings("serial")
public class GUIView extends Panel {
	/** The "Start Game" button */
	private Button startGameButton;
	
	/** The choise (also called drop-down) with names of different games */
	private Choice gameChooser;
	
	/** The game controller associated with the GameView */
	private GameController gameController;
	
	/** The game view on this panel */
	private GameView gameView;
	
	/** The panel with the gui-gadgets on this panel */
	private Panel guiPanel;
	
	/** This is the factory which creates GameModels for us */
	private GameFactory gameFactory;
	
	/**
	 * Create a new GUIView. This will create a GameView and a GameController.
	 */
	public GUIView() {
		// Create a new GameView
		gameView = new GameView();
		
		// Create a new GameController connected to the GameView
		gameController = new GameController(gameView);
		
		// Create a new GameFactory
		gameFactory = new GameFactory();
		
		// Set the background on the GameView
		gameView.setBackground(Color.white);
		
		// Set the layout on myself
		setLayout(new BorderLayout());
		
		// Make a new panel containing the GUI
		guiPanel = new Panel();
		
		// Set the background on that panel
		guiPanel.setBackground(Color.lightGray);
		
		// Create a new button on that panel and add a StartGameListener as
		// listener on that button
		startGameButton = new Button("Start Game");
		startGameButton.addActionListener(new StartGameListener());
		guiPanel.add(startGameButton);
		
		// Create a new choice on the panel, and add all available games
		gameChooser = new Choice();
		String[] gameNames = gameFactory.getGameNames();
		for(int i = 0; i < gameNames.length; i++)
		{
			gameChooser.add(gameNames[i]);
		}
		guiPanel.add(gameChooser);
		
		// Add both the new panel and the GameView to myself
		add(gameView, BorderLayout.CENTER);
		add(guiPanel, BorderLayout.SOUTH);
	}
	
	/**
	 * Get a reference to the game controller. Useful if game needs to be
	 * stopped by some other means, like in stop() in Applet.
	 */
	public GameController getGameController() {
		return gameController;
	}
	
	/**
	 * This inner class will listen for presses on the "Start Game" button.
	 * It will respond by creating a new game model and starting it using
	 * the game controller.
	 */
	private class StartGameListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Object source = e.getSource();
			
			if(source == startGameButton)
			{
				// Get the name of the game selected in the Choice
				String gameName = gameChooser.getSelectedItem();
				GameModel gameModel = gameFactory.createGame(gameName);
				
				// Stop current game (if any) and start a new game with the
				// new game model
				gameController.stopGame();
				gameController.startGame(gameModel);
				gameView.requestFocus();
			}
		}
	}
}
		
