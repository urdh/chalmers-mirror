package edu.chs.ssimon.tda550.lab1;

/**
 * A position object describes a
 * two-dimensional point.
 */
public class Position {

	public final int x;
	public final int y;

	/**
	 * Creates a new position.
	 */
	public Position(int x, int y) {
		this.x = x; 
		this.y = y;
	}

	/**
	 * Check whether other position equals this.
	 *
	 * @return true if this equals other.
	 */
	public boolean equals(Position other) {
		return ((x == other.x) && (y == other.y));
	}

        /**
	 * Check whether other position equals this.
	 *
	 * @return true if this equals other.
	 */
	public boolean equals(Object other) {
		if (other instanceof Position) {
			return equals((Position)other);
		}else {
			return false;
		}
	}
}
