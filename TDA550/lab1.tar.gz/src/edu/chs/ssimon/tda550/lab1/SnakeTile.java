/**
 * 
 */
package edu.chs.ssimon.tda550.lab1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

/**
 * Snake tile
 * 
 * @author Simon Sigurdhsson
 *
 */
public class SnakeTile extends FloorTile {
	/** Color of the snake */
	private Color sc;
	
	/**
	 * Create a new snake tile
	 * 
	 * @param t floor tile to build upon
	 * @param c color of the snake
	 */
	public SnakeTile(FloorTile t, Color c) {
		super(t.getC(), t.getE(), t.getL());
		this.sc = c;
	}

	/**
     * Draws itself in a given graphics context, position and size.
     *
     * @param g graphics context to draw on.
     * @param x pixel x coordinate of the tile to be drawn.
     * @param y pixel y coordinate of the tile to be drawn.
     * @param d size of this object in pixels.
     */
    public void draw(Graphics g, int x, int y, Dimension d) {
    	super.draw(g, x, y, d);
    	g.setColor(sc);
    	g.fillOval(x+2, y+2, d.width-4, d.height-4);
    }
}
