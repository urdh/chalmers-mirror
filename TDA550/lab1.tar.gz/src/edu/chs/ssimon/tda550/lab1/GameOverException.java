package edu.chs.ssimon.tda550.lab1;

/**
   Thrown by GameModel.doCommand at game termination. The exception contains information about how many points the player got.
*/
@SuppressWarnings("serial")
public class GameOverException extends Exception {
    private int score;
    
    public GameOverException(int score) {
	this.score = score;
    }

    /** Get the score of the game */
    public int getScore() {
	return score;
    }
}
