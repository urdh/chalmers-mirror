/**
 * 
 */
package edu.chs.ssimon.tda550.lab1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Polygon;

/**
 * Apple tile
 * 
 * @author Simon Sigurdhsson
 *
 */
public class AppleTile extends FloorTile {
	/** Color of the apple */
	private Color ac;
	
	private static final int[] xs = {1,2,2,4,6,7,8,9,8,8,9,10,8,9,11,12,13,11,11,13,13,11,9,8,7,6,4,2,2,1,1};
	private static final int[] ys = {8,7,6,4,4,5,5,4,3,2,1,1,3,4,4,5,5,7,9,11,12,14,14,13,13,14,14,12,11,10,8};
	private static final int points = 31;
	/** Apple graphic */
	private Polygon apple = new Polygon(xs, ys, points);
	
	/**
	 * Create a new apple tile
	 * 
	 * @param t floor tile to build upon
	 * @param c color of the apple
	 */
	public AppleTile(FloorTile t, Color c) {
		super(t.getC(), t.getE(), t.getL());
		this.ac = c;
	}

	/**
     * Draws itself in a given graphics context, position and size.
     *
     * @param g graphics context to draw on.
     * @param x pixel x coordinate of the tile to be drawn.
     * @param y pixel y coordinate of the tile to be drawn.
     * @param d size of this object in pixels.
     */
    public void draw(Graphics g, int x, int y, Dimension d) {
    	super.draw(g, x, y, d);
    	g.setColor(ac);
    	apple.translate(x+(d.width-15)/2,y+(d.height-16)/2);
    	g.fillPolygon(apple);
    	apple.translate(-x-(d.width-15)/2,-y-(d.width-15)/2);
    }
}
