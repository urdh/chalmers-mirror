package edu.chs.ssimon.tda550.lab1;

import java.awt.*;

/**
 * Factory class for available games.
 */
public class GameFactory {
	
	/**
	 * Returns a Dimension with the size of the gameboard in number of tiles
	 */
	public static Dimension getGameSize() {
		return new Dimension(20,20);
	}
	
	/**
	 * Returns an array with names of games this factory can create. Used by
	 * GUI list availible games.
	 */
	public String[] getGameNames()
	{
		return new String[] { "Gold", "Snake" };
	}
	
	/**
	 * Returns a new model object for the game corresponding to its 
	 * Name.
	 * @param gameName The name of the game as given by getGameNames()
	 * @throws IllegalArgumentException if no such game
	 */
	public GameModel createGame(String gameName) {
		if (gameName.equals("Gold")) {
			return new GoldModel();
		} else if (gameName.equals("Snake")) {
			return new SnakeModel();
		} else {
			throw new IllegalArgumentException("No such game: " + gameName);
		}
	}
}
