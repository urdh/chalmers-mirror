package edu.chs.ssimon.tda550.lab1;

import java.awt.*;

/** 
 * A rectangular tile manages painting of a
 * rectangle in a specified area of the screen.
 *
 * Whenever the object should paint itself, 
 * it is told what size and position that
 * should be used to paint it.
 */
public class RectangularTile extends GameTile {

    /** The color of the circle */
    private Color color;
    
    /**
     * Creates a circular game tile.
     *
     * @param color the color of the circle.
     */
    public RectangularTile(Color color) {
	this.color = color;
    }
    
    /**
     * Draws itself in a given graphics context, position and size.
     *
     * @param g graphics context to draw on.
     * @param x pixel x coordinate of the tile to be drawn.
     * @param y pixel y coordinate of the tile to be drawn.
     * @param d size of this object in pixels.
     */
    public void draw(Graphics g, int x, int y, Dimension d) {
	g.setColor(color);
	g.fillRect(x,y,d.width,d.height);
    }
}
