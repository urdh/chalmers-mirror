package edu.chs.ssimon.tda550.lab1;

import java.awt.*;
import java.awt.event.*;

/**
 * This class creates an AWT window which will contain the game.
 */
public class Main {
	public static void main(String[] args) {
		// Create a new frame (a window)
		Frame frame = new Frame();

		GUIView guiView = new GUIView();
		
		frame.setTitle("Games 2.0");

		// Add gui to window
		frame.add(guiView);
		
		// Listen to window so we can exit when the user wants to close the
		// window
		frame.addWindowListener(new GameWindowListener());
		
		// pack() will do the layout of the window so it gets the correct size
		frame.pack();
		
		// Open the window
		frame.setVisible(true);
		frame.requestFocus();
	}
}

/**
 * This class will close the window on user request
 */
class GameWindowListener extends WindowAdapter {
	/**
	 * Called when the user clicks the close button on the window.
	 * (the X-button in the upper right corner in Windows)
	 */
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
}
