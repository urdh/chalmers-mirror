package geometri;

import java.awt.*;

/**
 * This class describes a line as per the
 * <tt>GeometricalForm</tt> interface.
 * 
 * @see GeometricalForm
 * 
 * @author Simon Sigurdhsson
 */
public final class Line extends AbstractForm {
	
	private int w, h;
	private boolean slopeUp;
	
	/**
	 * Construct a new <tt>Line</tt> given coordinates from two other
	 * <tt>GeometricalForm</tt>s
	 * 
	 * @param f1 Form to get first position from
	 * @param f2 Form to get second position from
	 * @param c Color of the <tt>Line</tt>
	 */
	public Line(GeometricalForm f1, GeometricalForm f2, Color c) {
		super(f1, c);
		try {
			this.place(Math.min(f1.getX(), f2.getX()), Math.min(f1.getY(), f2.getY()));
		} catch(IllegalPositionException e) {
			throw new RuntimeException(); // Should never happen
		}
		if(f2.getY() < f1.getY()) this.slopeUp = true;
		this.w = Math.abs(f1.getX() - f2.getX());
		this.h = Math.abs(f1.getY() - f2.getY());
	}
	
	/**
	 * Construct a new <tt>Line</tt>
	 * 
	 * @param x1 X position of the starting point
	 * @param y1 Y position of the starting point
	 * @param x2 X position of the ending point
	 * @param y2 Y position of the ending point
	 * @param c Color of the <tt>Line</tt>
	 * @throws IllegalPositionException
	 */
	public Line(int x1, int y1, int x2, int y2, Color c) throws IllegalPositionException {
		super(x1, y1, c);
		if(y2 < y1) this.slopeUp = true;
		this.w = Math.abs(x1 - x2);
		this.h = Math.abs(y1 - y2);
	}

	/**
	 * {@inheritDoc}
	 */
	public int area() {
		return 0;
	}

	/**
	 * {@inheritDoc}
	 */
	public void fill(Graphics g) {
		g.setColor(this.getColor());
		g.drawLine(this.getX(), this.getY() + (this.slopeUp ? this.h : 0),
				   this.getX() + w, this.getY() + (this.slopeUp ? 0 : this.h));
	}

	/**
	 * {@inheritDoc}
	 */
	public int perimeter() {
		return (int) Math.sqrt(this.w*this.w + this.h*this.h);
	}
	
	/**
	 * Get slope of this line
	 * 
	 * @return Angle between this line and the horizontal axis
	 */
	public double angle() {
		return Math.asin((double)this.w / (double)this.perimeter());
	}
	
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object o) {
		if(o == null || this.getClass() != o.getClass()) return false;
		if(this == o) return true;
		Line g = (Line) o;
		return this.perimeter() == g.perimeter() && this.angle() == g.angle() && this.getColor() == g.getColor();
	}
}
