package geometri;

import java.awt.*;

/**
 * This class describes a circle as per the
 * <tt>GeometricalForm</tt> interface.
 * 
 * @see GeometricalForm
 * 
 * @author Simon Sigurdhsson
 */
public class Circle extends AbstractForm {
	
	// Håller inte med om att <tt>r</tt> skulle vara
	// intetsägande (det framgår lite av sammanhanget
	// att det är en radie det handlar om IMHO), men
	// ändrar ändå.
	private int radius;
	
	/**
	 * Construct a new <tt>Circle</tt> given coordinates from another
	 * <tt>GeometricalForm</tt>, as well the radius
	 * 
	 * @param f Form to get position from
	 * @param radius Radius of the new <tt>Circle</tt>
	 * @param c Color of the <tt>Circle</tt>
	 */
	public Circle(GeometricalForm f, int radius, Color c) {
		super(f, c);
		this.radius = radius;
	}
	
	/**
	 * Construct a new <tt>Circle</tt>
	 * 
	 * @param x X position of the <tt>Circle</tt>
	 * @param y Y position of the <tt>Circle</tt>
	 * @param radius Radius of the new <tt>Circle</tt>
	 * @param c Color of the <tt>Circle</tt>
	 * @throws IllegalPositionException
	 */
	public Circle(int x, int y, int radius, Color c) throws IllegalPositionException {
		super(x, y, c);
		this.radius = radius;
	}

	/**
	 * {@inheritDoc}
	 */
	public void fill(Graphics g) {
		g.setColor(this.getColor());
		g.fillOval(this.getX(), this.getY(), 2*this.radius, 2*this.radius);
	}

	/**
	 * {@inheritDoc}
	 */
	public int perimeter() {
		return (int) (2 * Math.PI * this.radius);
	}

	/**
	 * {@inheritDoc}
	 */
	public int area() {
		return (int) (Math.PI * this.radius * this.radius);
	}
	
	/**
	 * Get radius of this circle
	 * 
	 * @return Radius of this circle
	 */
	public int getRadius() {
		return this.radius;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object o) {
		if(o == null || this.getClass() != o.getClass()) return false;
		if(this == o) return true;
		Circle g = (Circle) o;
		return this.getRadius() == g.getRadius() && this.getColor() == g.getColor();
	}
}
