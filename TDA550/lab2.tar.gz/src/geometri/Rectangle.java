package geometri;

import java.awt.*;

/**
 * This class describes a rectangle as per the
 * <tt>GeometricalForm</tt> interface.
 * 
 * @see GeometricalForm
 * 
 * @author Simon Sigurdhsson
 */
public class Rectangle extends AbstractForm {
	
	private int w, h;
	
	/**
	 * Construct a new <tt>Rectangle</tt> given coordinates from another
	 * <tt>GeometricalForm</tt>, as well as width and height
	 * 
	 * @param f Form to get position from
	 * @param width Width of the <tt>Rectangle</tt>
	 * @param height Height of the <tt>Rectangle</tt>
	 * @param c Color of the <tt>Rectangle</tt>
	 */
	public Rectangle(GeometricalForm f, int width, int height, Color c) {
		super(f, c);
		this.w = width;
		this.h = height;
	}
	
	/**
	 * Construct a new <tt>Rectangle</tt>
	 * 
	 * @param x X position of the <tt>Rectangle</tt>
	 * @param y Y position of the <tt>Rectangle</tt>
	 * @param width Width of the <tt>Rectangle</tt>
	 * @param height Height of the <tt>Rectangle</tt>
	 * @param c Color of the <tt>Rectangle</tt>
	 * @throws IllegalPositionException
	 */
	public Rectangle(int x, int y, int width, int height, Color c) throws IllegalPositionException {
		super(x, y, c);
		this.w = width;
		this.h = height;
	}

	/**
	 * {@inheritDoc}
	 */
	public int area() {
		return this.w * this.h;
	}

	/**
	 * {@inheritDoc}
	 */
	public void fill(Graphics g) {
		g.setColor(this.getColor());
		g.fillRect(this.getX(), this.getY(), this.w, this.h);
	}

	/**
	 * {@inheritDoc}
	 */
	public int perimeter() {
		return 2 * this.w * this.h;
	}
	
	/**
	 * Get width of this rectangle
	 * 
	 * @return Width of this rectangle
	 */
	public int getWidth() {
		return w;
	}
	
	/**
	 * Get height of this rectangle
	 * 
	 * @return Height of this rectangle
	 */
	public int getHeight() {
		return h;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object o) {
		if(o == null || this.getClass() != o.getClass() && o.getClass() != Square.class) return false;
		if(this == o) return true;
		Rectangle g = (Rectangle) o;
		return this.getWidth()== g.getWidth() && this.getHeight() == g.getHeight() && this.getColor() == g.getColor();
	}
}
