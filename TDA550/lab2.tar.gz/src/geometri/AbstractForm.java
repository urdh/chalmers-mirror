package geometri;

import java.awt.Color;
import java.awt.Graphics;

/**
 * This class describes a form as per the
 * <tt>GeometricalForm</tt> interface.
 * 
 * @see GeometricalForm
 * 
 * @author Simon Sigurdhsson
 */
public abstract class AbstractForm implements GeometricalForm {

	private int x1, y1;
	private Color c;
	
	/**
	 * Construct an abstract form.
	 * 
	 * @param x Initial x position
	 * @param y Initial y position
	 * @param c Form color
	 */
	public AbstractForm(int x, int y, Color c) throws IllegalPositionException {
		this.place(x, y);
		this.c = c;
	}
	
	/**
	 * Construct an abstract form given coordinates from another
	 * <tt>GeometricalForm</tt>.
	 * 
	 * @param x Initial x position
	 * @param y Initial y position
	 * @param c Form color
	 */
	public AbstractForm(GeometricalForm f, Color c) {
		this.place(f);
		this.c = c;
	}

	/**
	 * {@inheritDoc}
	 */
	public abstract int area();

	/**
	 * {@inheritDoc}
	 */
	public int compareTo(GeometricalForm f) {
		if(this.area() != f.area()) return this.area() - f.area();
		return this.perimeter() - f.perimeter();
	}

	/**
	 * {@inheritDoc}
	 */
	public abstract void fill(Graphics g);

	/**
	 * {@inheritDoc}
	 */
	public Color getColor() {
		return this.c;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getX() {
		return this.x1;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getY() {
		return this.y1;
	}

	/**
	 * {@inheritDoc}
	 */
	public abstract int perimeter();

	/**
	 * {@inheritDoc}
	 */
	public void move(int dx, int dy)
			throws IllegalPositionException {
		if(this.x1 + dx < 0 || this.y1 + dy < 0)
			throw new IllegalPositionException("Trying to move Form to invalid location ("+(this.x1+dx)+","+(this.y1+dy)+")");
		this.x1 += dx;
		this.y1 += dy;
	}

	/**
	 * {@inheritDoc}
	 */
	public void place(int x, int y)
			throws IllegalPositionException{
		if(x < 0 || y < 0)
			throw new IllegalPositionException("Trying to place Form at invalid location ("+x+","+y+")");
		this.x1 = x;
		this.y1 = y;
	}
	
	/**
     * Place the form on coordinates given by the form <tt>f</tt>.
     *
     * @param f Form to get coordinates from
     */
	private void place(GeometricalForm f){
		try {
			this.place(f.getX(), f.getY());
		} catch(IllegalPositionException e) {
			throw new RuntimeException(); // Should never happen
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int hashCode() {
		return 17*this.area()+19*this.perimeter()+this.c.hashCode();
	}
	
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object o) {
		if(o == null || this.getClass() != o.getClass()) return false;
		return (this == o);
	}
}