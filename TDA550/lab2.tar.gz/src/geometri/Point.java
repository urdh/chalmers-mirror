package geometri;

import java.awt.*;

/**
 * This class describes a single point as per the
 * <tt>GeometricalForm</tt> interface.
 * 
 * @see GeometricalForm
 * 
 * @author Simon Sigurdhsson
 */
public class Point extends AbstractForm {
	
	/**
	 * Construct a new <tt>Point</tt> at the same position as another <tt>GeometricalForm</tt>
	 * 
	 * @param f form to get position from
	 * @param c Color of the <tt>Point</tt>
	 */
	public Point(GeometricalForm f, Color c) {
		super(f, c);
	}
	
	/**
	 * Construct a new <tt>Point</tt>
	 * 
	 * @param x X position of the <tt>Point</tt>
	 * @param y Y position of the <tt>Point</tt>
	 * @param c Color of the <tt>Point</tt>
	 * @throws IllegalPositionException
	 */
	public Point(int x, int y, Color c) throws IllegalPositionException {
		super(x, y, c);
	}

	/**
	 * {@inheritDoc}
	 */
	public int area() {
		return 0;
	}

	/**
	 * {@inheritDoc}
	 */
	public void fill(Graphics g) {
		g.setColor(this.getColor());
		g.drawLine(this.getX(), this.getY(), this.getX(), this.getY());
	}

	/**
	 * {@inheritDoc}
	 */
	public int perimeter() {
		return 0;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public boolean equals(Object o) {
		if(o == null || this.getClass() != o.getClass()) return false;
		if(this == o) return true;
		Point g = (Point) o;
		return this.getColor() == g.getColor();
	}
}
