/**
 * 
 */
package geometri;

import java.awt.Color;

/**
 * This class describes a square as per the
 * <tt>GeometricalForm</tt> interface. A square is in fact
 * a special <tt>Rectangle</tt>, where all four sides are of equal length.
 * 
 * @see GeometricalForm
 * @see Rectangle
 * 
 * @author Simon Sigurdhsson
 */
public final class Square extends Rectangle {

	/**
	 * Construct a new <tt>Square</tt> given coordinates from another
	 * <tt>GeometricalForm</tt>, as well as side length
	 * 
	 * @param f Form to get position from
	 * @param side Length of the <tt>Square</tt> side
	 * @param c Color of the <tt>Square</tt>
	 */
	public Square(GeometricalForm f, int side, Color c) {
		super(f, side, side, c);
	}

	/**
	 * Construct a new <tt>Square</tt>
	 * 
	 * @param x X position of the <tt>Square</tt>
	 * @param y Y position of the <tt>Square</tt>
	 * @param side Length of the <tt>Square</tt> side
	 * @param c Color of the <tt>Square</tt>
	 * @throws IllegalPositionException
	 */
	public Square(int x, int y, int side, Color c) throws IllegalPositionException {
		super(x, y, side, side, c);
	}

	// NOTE: Square doesn't have to implement equals() - Rectangle does that.
	//       All Squares are rectangles, and "square" rectangles *should* be
	//       equal to square squares of the same dimension.
}
