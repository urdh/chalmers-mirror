function yt = eulerf(fun, interval, yk, h)
    tk = interval(1);
    yt = yk';
    while(tk <= interval(2) && sqrt(yk(1)^2 + yk(2)^2) <= 1)
        y = yk + h*fun(tk, yk);
        tk = tk+h; yk = y;
        yt = [yt; yk'];
    end