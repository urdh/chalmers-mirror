function yk = fixpi(fun, y, h)
    yk = fun(y);
    while(abs(yk-y) > h)
       y = yk;
       yk = fun(y);
    end