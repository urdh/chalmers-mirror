function [val stopp riktn] = prob1(t, y)
    val = sqrt(y(1)^2 + y(2)^2) - 1;
    stopp = [1];
    riktn = [1];