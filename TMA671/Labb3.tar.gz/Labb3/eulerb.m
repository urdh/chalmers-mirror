function yt = eulerb(fun, interval, yk, h)
    tk = interval(1);
    yt = yk';
    while(tk <= interval(2) && sqrt(yk(1)^2 + yk(2)^2) <= 1)
        yk1 = eulerf(fun, [tk+h tk+h], yk, h)';
        y = yk + h*fun(tk+h, yk1(:,end));
        tk = tk+h; yk = y;
        yt = [yt; yk'];
    end