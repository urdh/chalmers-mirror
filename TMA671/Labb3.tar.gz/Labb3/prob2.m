function v = prob2(u)
    v0 = [1 0 u 0]';
    yp = @(t, y) [0 0 1 0; 0 0 0 1; 0 0 0 1; 0 0 -1 0]*y + [0 0 1 0]';
    opt = odeset('Events', @prob1);
    [T V] = ode45(yp, [0 2], v0, opt);
    lamnar = V(end,1:2);
    v = lamnar - [0 1];