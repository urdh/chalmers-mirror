%%
%%   LABB 3
%%

%% Set up a suitable grid
%  Also, draw a nice circle
[X Y] = meshgrid(-1:0.1:1,-1:0.1:1);
contour(X, Y, X.^2 + Y.^2, [1 1], 'k');
axis([-1.2 1.2 -1.2 1.2]);
axis square;
grid on;
hold on;

%% a)
v0 = [1 0 -2 0]';
yp = @(t, y) [0 0 1 0; 0 0 0 1; 0 0 0 1; 0 0 -1 0]*y + [0 0 1 0]';
opt = odeset('Events', @prob1);
[T V] = ode45(yp, [0 2], v0, opt);
X = V(:,1);
Y = V(:,2);
lamnar = [X(end) Y(end)]        % Punkten då elektronen lämnar cirkeln
% Partikeln fortsätter i en rak linje
dX = X(end) - X(size(X,1)-1);
dY = Y(end) - Y(size(Y,1)-1);
k = dY/dX;
X = [X; X(end)+1];
Y = [Y; Y(end)+k];
plot(X,Y,'r');
% lamnar = [-0.2314    0.9729]

%% b) Euler framåt
V = eulerf(yp, [0 2], v0, 0.1);
X = V(:,1);
Y = V(:,2);
lamnar = [X(end) Y(end)]        % Punkten då elektronen lämnar cirkeln
% Partikeln fortsätter i en rak linje
dX = X(end) - X(size(X,1)-1);
dY = Y(end) - Y(size(Y,1)-1);
k = dY/dX;
X = [X; X(end)+1];
Y = [Y; Y(end)-k]; % -k eftersom den rör sig bakåt i x-led
plot(X,Y,'b--');
% lamnar = [-0.3643    1.0107]

%% b) Euler bakåt
V = eulerb(yp, [0 2], v0, 0.1);
X = V(:,1);
Y = V(:,2);
lamnar = [X(end) Y(end)]        % Punkten då elektronen lämnar cirkeln
% Partikeln fortsätter i en rak linje
dX = X(end) - X(size(X,1)-1);
dY = Y(end) - Y(size(Y,1)-1);
k = dY/dX;
X = [X; X(end)+1];
Y = [Y; Y(end)+k];
plot(X,Y,'g--');
% lamnar = [-0.0958    1.0121]

%% b) Trapetsmetoden
V = trapets(yp, [0 2], v0, 0.1);
X = V(:,1);
Y = V(:,2);
lamnar = [X(end) Y(end)]        % Punkten då elektronen lämnar cirkeln
% Partikeln fortsätter i en rak linje
dX = X(end) - X(size(X,1)-1);
dY = Y(end) - Y(size(Y,1)-1);
k = dY/dX;
X = [X; X(end)+1];
Y = [Y; Y(end)+k];
plot(X,Y,'c--');
% lamnar = [-0.2264    1.0118]

%% c) Trapetsmetoden är klart bäst, eftersom den är ett medelvärde av euler
%% framåt och euler bakåt. Se figur.

%% d)
egenvarden = eig([0 0 1 0; 0 0 0 1; 0 0 0 1; 0 0 -1 0])'
% Egenvärdena är 0, 0, +i och -i.
% För euler framåt ligger endast nollan i stabilitetsområdet (abs(1+z) <= 1).
% Metoden är alltså inte stabil för det aktuella problemet.
% För euler bakåt och trapetsmetoden, som båda är A-stabila, dvs.
% stabilitetsområdet inkluderar hela Re(z) <= 0. Då alla egenvärden
% uppfyller detta är metoderna stabila för det aktuella problemet.
% I praktiken betyder detta att man inte bör använda euler framåt om det
% finns risk för att små fel smugit sig in i mätdata. Att en metod är
% instabil innebär att små skillnader i indata ger stora fel i utdata.
% Stabila metoder konvergerar mot samma lösning även om små fel finns i
% indata.

%% e)
u = fsolve(@prob2, -2)
v0 = [1 0 u 0]';
opt = odeset('Events', @prob1);
[T V] = ode45(yp, [0 2], v0, opt);
X = V(:,1);
Y = V(:,2);
% Partikeln fortsätter i en rak linje
dX = X(end) - X(size(X,1)-1);
dY = Y(end) - Y(size(Y,1)-1);
k = dY/dX;
X = [X; X(end)+1];
Y = [Y; Y(end)+k];
plot(X,Y,'m');
% u = -1.8052