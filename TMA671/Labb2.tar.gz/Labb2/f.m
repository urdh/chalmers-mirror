function y = f(x, dim)
    % x ska vara en (kolonn-)vektor i formatet [x y z x y z ...]
    pktr = reshape(x, dim, size(x,1)/dim)';
    distance = 0;
    % Totala avståndet mellan alla punkter
    for i=1:size(pktr, 1)
        distance = distance + norm(pktr(mod(i,size(pktr, 1))+1,:) - pktr(i, 1));
    end
    y = -distance;