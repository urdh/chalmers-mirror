function x = placepoints(dim, points)
    x0 = rand(dim, points);
    opts = optimset('MaxIter', 1e18, 'MaxFunEvals', 1e18, 'Largescale', 'off');

    x = fmincon(@fun, x0, [], [], [], [], [], [], @nonlcon, opts);