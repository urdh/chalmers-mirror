%% a) Lös problemet med en matlab-fil som anropar funktionen fmincon
%placepoints(2, 4)
%placepoints(3, 6)
%placepoints(4, 8)

%% b) Fallet n=6, m=3
[sx, sy, sz] = sphere(32);
surf(sx, sy, sz);
axis equal;
hold on;
colormap summer;
alpha 0.3;
shading flat;
x = placepoints(3, 6);
scatter3(x(1,:), x(2,:), x(3,:))

%% c) Diagonaldominans
A = x'*x;
b = zeros(size(A, 1), 1);
for j=1:size(A, 1)
    for i=1:size(A, 1)
        if(i == j)
            b(j) = b(j) + A(i, j); 
        else
            b(j) = b(j) - A(i, j);
        end
    end
end
alph = min(b)

%% d) Rotation
v = x(:,1) - norm(x(:,1))*[1 0 0]';
v = v/norm(v);
H = eye(3) - 2*v*v';
Hx = H*x;
v2 = Hx(:,2) - norm(Hx(:,2))*[0 1 0]';
v2 = v2/norm(v2);
H2 = eye(3) - 2*v2*v2';
H2x = H2*Hx;
%{
for i=1:6
    rX = round(acosd(dot(Hx(:,i), [0 1 0])));
    if(Hx(2,i) > 0 && Hx(3,i) < 0) rX = acos(dot(Hx(:,i),[0 1 0])); break; end
end
rM = [1 0 0;0 cos(rX) -sin(rX);0 sin(rX) cos(rX)];
Rx = rM*Hx;
%}
Rx = H2x;

scatter3(Rx(1,:), Rx(2,:), Rx(3,:), 'ro')
line([-1 1], [0 0], [0 0], 'Color', 'k')
line([0 0], [-1 1], [0 0], 'Color', 'k')
line([0 0], [0 0], [-1 1], 'Color', 'k')