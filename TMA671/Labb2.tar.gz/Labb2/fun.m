function y=fun(x)
    len = size(x, 2);
    A = zeros(len);
    for i=1:len
        for j=1:len
            A(i, j) = norm(x(:,i) - x(:,j));
            if(A(i,j) == 0) A(i, j) = Inf; end;
        end
    end
    y = -min(min(A));