function [c, ceq] = nonlcon(x)
    c = -ones(size(x,2),1);
    ceq = sqrt(sum(x.^2, 1)) - ones(size(x,2), 1)';