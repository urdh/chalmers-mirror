%%
%%   LABB 1
%%

%% a)
clf
a = 0e-6;
b = 3e-6;
x = [0:1e-8:3e-6];
opt=optimset('TolX', 1e-10);
figure(1)
hold on

for T = 3000:1000:5000
[lambda_max ymax] = fminbnd(@(lambda) -planck(lambda, T), a, b, opt)
k=lambda_max*T
y = planck(x, T);
plot(x,y,'r');
plot(lambda_max,-ymax,'ro');
end

plot([a a],[0 4.5e13],'g');
plot([b b],[0 4.5e13],'g');

% Lagen verkar stämma, konstanten blir 2.9e-3

%% b)
f = @(x) (5-x).*exp(x)-5;
x = [4.9:1e-6:5];
y = f(x);
figure(2)
plot(x,y);

start = ginput(1);

x0 = newton(f, start(1), 1e-10)
h=6.6256e-34;c=2.9979e8;k=1.3805e-23;
k = h*c/(k*x0)

% k = 2.9e-3

%% c)
sigma=5.67e-8;
M = @(T) quadl(@(lambda) planck(lambda,T), 4e-7, 7e-7);
Mx = [];
Tx = [];
for T=0:100:10000
  Tx = [Tx T];
  Mx = [Mx M(T)./(sigma*T.^4)];
end
figure(3)
plot(Tx,Mx);

% Se figur

%% d)
sigma=5.67e-8;
Ux = [];
Tx = [];
for T=0:100:10000
  [t, U] = ode45(@(lambda, x) planck(lambda,T), [4e-7, 7e-7], 0);
  Ux = [Ux U(end)/(sigma*T.^4)];
  Tx = [Tx T];
end
figure(4)
plot(Tx,Ux);