function wienexec(val)
% Anv�ndarinterface f�r laboration 1 i Linj�r algebra och analys, F1, 2003
% B�rja l�mpligen med att rita upp Plancks funktion, f�r vald temperatur
% genom att trycka p� knappen "Rita funktion".
% Tryck p� hold f�r att stanna grafiken.
% Markera intervallet synligt ljus genom att trycka p� knappen
% "Ange synligt ljus".
% Markera emittansen av synligt ljus, eller annat intervall, genom att
% trycka p� "Visa intervall".
% Vill Du rita f�r en annan temperatur �r det bara att trycka "Hold" och
% g�ra om alltsammans.
% Avsluta med "stopp", viktigt f�r att �terst�lla vissa variablers v�rden.   

persistent h handles 
if nargin == 0
    val=0;
end

switch val
case 0
   fig=open('wien.fig');
   handles=guihandles(fig);          % Ge handtagen namn
case 1
   T=get(handles.edit5,'string');    % Temperaturens handtag
   T=str2num(T);
   lambda=0.01:0.01:3;
   lambda=1e-6*lambda;
   colordef black
   plot(lambda,planck(lambda,T));
   title('Emittans vid svartkroppsstr�lning enligt Plancks lag')
   xlabel('V�gl�ngd')
case 2
   T=get(handles.edit5,'string');    % Temperaturens handtag
   T=str2num(T);
   intervall=get(handles.edit9,'string');   % Intervallets handtag
   synligt=str2num(intervall);
   lambdasynl=linspace(synligt(1),synligt(2),50);
   area(lambdasynl,planck(lambdasynl,T));
   xlabel('V�gl�ngd')
   title('Emittans av synligt ljus')
case 3
   v=axis;
   fill([4e-7 7e-7 7e-7  4e-7], [0 0 v(4) v(4)], [0 1 1 0])  
case 4
   hold
case 5
    colordef white
    hold off
    delete(gcf)
end
