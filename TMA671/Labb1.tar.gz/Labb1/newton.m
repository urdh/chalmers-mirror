function z=newton(func, x0, epsilon)
    diff = func(x0) - func(x0+epsilon);
    k = diff/epsilon;
    x = x0 + func(x0)/k;
    if(abs(x-x0) < epsilon) z = x;
    else z = newton(func, x, epsilon);
    end