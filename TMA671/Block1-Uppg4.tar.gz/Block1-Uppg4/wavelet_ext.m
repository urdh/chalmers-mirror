function out=wavelet_ext(in, with)
	tout = [zeros(size(in)); zeros(size(in))];
	for k=1:size(in).^2
		i = (k*2-1);
		tout(i:i+1) = with*in(k);
	end
	out = tout';