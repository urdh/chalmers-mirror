% Skapa funktion
f = @(x) exp(x).*cos(pi*x);
% Generera funktionsv�rden
x_1 = linspace(0,3,16);
x_2 = linspace(0,3,32);
x_3 = linspace(0,3,64);
f_1 = f(x_1);
f_2 = f(x_2);
f_3 = f(x_3);
% Komprimera med wavelets
w_1 = compress(f_1, 1.5);
w_2 = compress(f_2, 1.0);
w_3 = compress(f_3, 0.5);
% Dekomprimera
v_1 = inflate(w_1);
v_2 = inflate(w_2);
v_3 = inflate(w_3);
% Felv�rden
fel_1 = norm(f_1-v_1)/16;
fel_2 = norm(f_2-v_2)/32;
fel_3 = norm(f_3-v_3)/64;
% Figurer
figure(1); hold on; plot(x_1, f_1, 'g'); plot(x_1, v_1, 'r');
figure(2); hold on; plot(x_2, f_2, 'g'); plot(x_2, v_2, 'r');
figure(3); hold on; plot(x_3, f_3, 'g'); plot(x_3, v_3, 'r');
% Komprimeringsgrad
grad_1 = length(find(w_1))/length(find(f_1));
grad_2 = length(find(w_2))/length(find(f_2));
grad_3 = length(find(w_3))/length(find(f_3));
% Utskrift
disp( 'n =     16      32      64')
disp(['fel:  ' num2str(fel_1, '%1.4f') '  ' num2str(fel_2, '%1.4f') '  ' num2str(fel_3, '%1.4f')])
disp(['grad: ' num2str(grad_1, '%1.4f') '  ' num2str(grad_2, '%1.4f') '  ' num2str(grad_3, '%1.4f')])