function out=inflate(v, epsilon)
    A = [1/2 1/2]; B = [1/2 -1/2]; Z = [0 0];
    [no s] = size(v);
    A_1 = [wavelet_ext(eye(s/2), A); wavelet_ext(eye(s/2), B)];
    A_2 = [wavelet_ext(eye(s/4), A) zeros(s/4, s/2);
            wavelet_ext(eye(s/4), B) zeros(s/4, s/2);
            zeros(s/2, s/2) eye(s/2)];
    A_3 = [wavelet_ext(eye(s/8), A) zeros(s/8, 3*s/4);
            wavelet_ext(eye(s/8), B) zeros(s/8, 3*s/4);
            zeros(3*s/4, s/4) eye(3*s/4)];
    out=(A_1\(A_2\(A_3\v')))';