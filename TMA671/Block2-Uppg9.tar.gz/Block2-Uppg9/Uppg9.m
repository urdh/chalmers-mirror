%% a)
a = 0.5; b = 0.05; d = 4;
g = [1.4 1.5 1.3];
for i = 1:3
    x = [0];
    r = [20];
    k = [500];
    for j=1:100
        r = [r a*r(j)+b*k(j)];
        k = [k g(i)*k(j)-d*r(j)];
        x = [x j];
    end·
    [r(end) k(end)]
    subplot(3,2,i*2-1);
    plot(x,r,'r',x,k,'b');
    title(['Rävar & kaniner, \gamma=' num2str(g(i))]);
    legend('Rävar','Kaniner');
    axis square;
    % c)
    subplot(3,2,i*2);
    plot(r,k,'b');
    title(['Fasporträtt, \gamma=' num2str(g(i))]);
    axis square;
end
%% Stuff
a = 0.5; b = 0.05; d = 4;
g = [1.4 1.5 1.3];
for i = 1:3
        [V D] = eig([a b; -d g(i)])
        %disp(['Egenvärden då \gamma=' num2str(g(i)) ': ' num2str(D(1,1)) ' och ' num2str(D(2,2))])
end