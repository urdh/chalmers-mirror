%% encode.m
function f = encode(p,A) 
  p=[p,' ',' ',' ']; 
  m=floor(length(p)/4); 
  pp=abs(reshape(p(1:4*m),4,m)); 
  cc=A*pp; 
  f=char(reshape(cc,1,4*m));