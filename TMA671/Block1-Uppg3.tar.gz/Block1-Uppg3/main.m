%% LANA, Block 1, Uppgift 3
%% "Kryptografi"
%% Simon Sigurdhsson, TM1

load krypto.mat

%% Del A.
A_1 = [1,1,0,0;
       1,0,1,1;
       1,0,2,1;
       0,1,0,1]
text_1 = decode(code_1, A_1)

%% Del B.
A_2 = crack(code_2, 'The significant problems')
text_2 = decode(code_2, A_2)

%% Del C.
A_3 = crack(code_3, 'Nej Nej ? vektorerna ej oberoende ...')
text_3 = decode(code_3, A_3)

%%%% K�rningsresultat
%% Del A.
% A_1 =
%
%     1     1     0     0
%     1     0     1     1
%     1     0     2     1
%     0     1     0     1
%
%
% text_1 =
%
% Everything should be made as simple as possible but not simpler. (A Einstein) 
%
%% Del B.
% A_2 =
%
%     0     1     2     0
%     1     0     0     2
%     1     1     1     2
%     0     2     2     1
%
%
% text_2 =
%
% The significant problems we face cannot be solved at the same level of thinking we were at when we created them. (A. Einstein)     
%
%% Del C.
% A_3 =
%
%     1     2     1     0
%     2     1     0     1
%     0     1     0     1
%     0     2     1     1
%
%
% text_3 =
%
% Nej Nej - vektorerna ej oberoende - se upp med icke inverterbara matriser      
%
%%%%