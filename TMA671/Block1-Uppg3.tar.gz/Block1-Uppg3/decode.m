%% decode.m
function p = decode(f,A) 
  m=floor(length(f)/4); 
  pp=abs(reshape(f(1:4*m),4,m));
  cc=round(A\pp);
  cc(all(cc==0,2),:)=[];
  p=char(reshape(cc,1,4*m)); 
  p=[p,' ',' ',' ']; 