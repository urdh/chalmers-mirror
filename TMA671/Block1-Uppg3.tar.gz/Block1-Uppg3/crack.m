%% crack.m
function A = crack(c,t) 
  m=min(floor([length(c) length(t)]/4));
  ss=abs(reshape(t(1:4*m),4,m));
  cc=abs(reshape(c(1:4*m),4,m));
  A=round(cc/ss);