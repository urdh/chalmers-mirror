t=[1 2 3 4 5 6 7 8 9 10 11 12];
y=[-1.8 -2.0 0.7 5.4 10.8 14.8 17.0 16.3 12.5 8.0 3.9 1.1]';
w=pi/6;

% Approx. 1
si=sin(w*t); co=cos(w*t);
A=[1 1 1 1 1 1 1 1 1 1 1 1; si ; co ]';
c=A\y; x=0:0.1:13;
f=c(1)+c(2)*sin(w*x)+c(3)*cos(w*x);
plot(x,f,'b')
hold on
plot(t,y,'or')

% Approx. 2
co2=cos(2*w*t); si2=sin(2*w*t);
B=[1 1 1 1 1 1 1 1 1 1 1 1; si ; co ; si2 ; co2]';
d=B\y; x=0:0.1:13;
f2=d(1)+d(2)*sin(w*x)+d(3)*cos(w*x)+d(4)*sin(2*w*x)+d(5)*cos(2*w*x);
plot(x,f2,'g')
axis on

% Residualnormer
res1= y-A*c;
norm(res1)
res2=y-B*d;
norm(res2)

f = @(x) c(1)+c(2)*sin(w*x)+c(3)*cos(w*x);
r1=fsolve(f,12);
f2= @(x) d(1)+d(2)*sin(w*x)+d(3)*cos(w*x)+d(4)*sin(2*w*x)+d(5)*cos(2*w*x);
r2 = fsolve(f2,12);
% Skillnaden i dagar
abs(r1-r2)*(365/12)